import {
  InstitutionInfo,
  OrderCircular,
  EventItem,
  PrincipalDeskInfo,
  TradeItem,
  HeroInfo,
  GalleryPhoto,
  WhyChoosePoint,
  CitizenHubItem,
  NationalPortal,
  TenderNotice,
  RtiOfficer,
  FacilityItem,
  MandatoryDisclosureItem
} from '../types';

export const initialInstitutionInfo: InstitutionInfo = {
  state: 'GOVERNMENT OF JAMMU & KASHMIR',
  department: 'DIRECTORATE OF TECHNICAL EDUCATION & SKILL DEVELOPMENT',
  instituteName: 'GOVT INDUSTRIAL TRAINING INSTITUTE, UDHAMPUR',
  subLocation: 'Near District Hospital, Udhampur - 182101 (J&K)',
  helpline: '+91 1992 270428',
  email: 'itiudhampur@gmail.com',
  address: 'Dhar Road, Near District Hospital, Udhampur - 182101',
  district: 'Udhampur',
  pincode: '182101',
  estdYear: '1974',
  ncvtCode: 'GR01000002',
  ncvtMisCode: 'GU01000011',
  affiliationText: 'Affiliated to DGT, Govt of India',
  workingHours: '10:00 AM - 4:00 PM (Monday to Saturday)',
  visitorCount: 482914,
  lastUpdated: '29 May 2026'
};

export const initialTickerAlerts: string[] = [
  'Online Admission Notification for Academic Session 2026-27 released. Merit lists & counseling schedule for Craftsmen Training Scheme (CTS) available now.',
  'Campus Placement Drive by Maruti Suzuki & Tata Power on 28th April 2026 at ITI Auditorium.',
  'Disbursement of Post-Matric & Pragati Scholarships for Academic Year 2025-26 under Direct Benefit Transfer (DBT).',
  'NCVT CBT Supplementary Examination Admit Cards uploaded on Trainee Profile MIS Portal.'
];

export const initialHeroInfo: HeroInfo = {
  taglineBadge: 'ESTD 1974 · NCVT MIS Code: GU01000011 · Affiliated to DGT, Govt of India',
  titlePrefix: 'Empowering Youth with ',
  titleHighlight: 'Industry-Ready',
  titleSuffix: ' Technical Craftsmanship',
  description: "Jammu & Kashmir's premier institution for Craftsmen Training Scheme (CTS). Hands-on workshops, Dual System of Training (DST), and globally accredited certifications.",
  stat1Value: '15+',
  stat1Label: 'Active CTS Trades',
  stat2Value: '300+',
  stat2Label: 'Annual Enrolled Trainees',
  stat3Value: '1 CITS Trade',
  stat3Label: 'Sewing Technology',
  stat3Sub: 'Advanced National Craft Instructor',
  stat4Value: '50+',
  stat4Label: 'Years of Heritage',
  heroPhotoUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
  heroPhotoBadge: 'CAMPUS LIFE Near District Hospital Udhampur',
  heroPhotoCaption: 'Modern Workshop Infrastructure & Smart Labs'
};

export const initialOrdersCirculars: OrderCircular[] = [
  {
    id: 'ord-1',
    title: 'Final Selection List for Round-1 Counseling for Electrician, Fitter, and COPA (Session 2026-27)',
    refNo: 'ITIU/Adm/2026/841',
    date: '28-04-2026',
    category: 'URGENT',
    fileSize: 'PDF (1.2 MB)',
    downloadCount: 1420,
    issuingAuthority: 'Admission Committee, Govt ITI Udhampur',
    description: 'Candidates placed in merit list Round-1 are directed to report with original documents and admission fee before 05-05-2026.'
  },
  {
    id: 'ord-2',
    title: 'Date Sheet & Examination Guidelines for AITT CTS CBT Examination (July 2026 Session)',
    refNo: 'NCVT/Exam/CTS/2026/309',
    date: '22-04-2026',
    category: 'EXAM',
    fileSize: 'PDF (840 KB)',
    downloadCount: 980,
    issuingAuthority: 'NCVT Examination Cell, New Delhi / J&K',
    description: 'All trainees are advised to download their mock CBT practice software guidelines and verify hall ticket signatures.'
  },
  {
    id: 'ord-3',
    title: 'E-Tender Notice for Supply & Commissioning of CNC Simulation Software & Lathe Tooling',
    refNo: 'Tender ID: 2026_DSD_99412',
    date: '15-04-2026',
    category: 'TENDER',
    fileSize: 'PDF (2.4 MB)',
    downloadCount: 310,
    issuingAuthority: 'Purchase Committee, Directorate of Skill Development J&K',
    description: 'Sealed bids are invited through jktenders.gov.in from authorized OEMs for equipping the modern Precision Engineering Workshop.'
  },
  {
    id: 'ord-4',
    title: 'Disbursement of Pragati Scholarship & Post-Matric Financial Aid for SC/ST/EWS Trainees',
    refNo: 'DSD/Sch/2026/410',
    date: '09-04-2026',
    category: 'SCHEME',
    fileSize: 'PDF (520 KB)',
    downloadCount: 654,
    issuingAuthority: 'Directorate of Social Welfare & Skill Development J&K',
    description: 'Beneficiary lists released for verified trainees under National Scholarship Portal (NSP). Direct bank transfer initiated.'
  },
  {
    id: 'ord-5',
    title: 'Guidelines for Dual System of Training (DST) Industrial Internship with Maruti Suzuki Service',
    refNo: 'ITIU/DST/2026/112',
    date: '02-04-2026',
    category: 'GENERAL',
    fileSize: 'PDF (1.8 MB)',
    downloadCount: 422,
    issuingAuthority: 'Industry Liaison & Placement Cell',
    description: 'Mandatory on-the-job training orientation guidelines for 2nd-year Mechanic Motor Vehicle and Welder trades.'
  }
];

export const initialEvents: EventItem[] = [
  {
    id: 'ev-1',
    day: '02',
    monthYear: "MAY '26",
    category: 'PLACEMENT MELA',
    title: 'National Apprenticeship Mela (NAM) 2026',
    description: 'Collaboration with DGT. 25+ top industrial recruiters visiting ITI campus for on-the-spot apprentice contracts.',
    time: '09:30 AM onwards',
    venue: 'Main Campus Assembly Ground & Smart Hall'
  },
  {
    id: 'ev-2',
    day: '15',
    monthYear: "MAY '26",
    category: 'CAMPUS FEST',
    title: 'Annual Skill Exhibition & District Tech Fest',
    description: 'Showcasing live working models by Electrician, Welder, and MMV trainees at District Pavilion.',
    time: '10:00 AM - 5:00 PM',
    venue: 'ITI Workshop Arena'
  },
  {
    id: 'ev-3',
    day: '23',
    monthYear: "MAY '26",
    category: 'WORKSHOP',
    title: 'PM Surya Ghar Solar Technician Masterclass',
    description: 'Intensive rooftop PV installation training in association with Jammu Power Distribution Corporation Limited (JPDCL).',
    time: '11:00 AM - 3:30 PM',
    venue: 'Renewable Energy Lab'
  },
  {
    id: 'ev-4',
    day: '05',
    monthYear: "JUN '26",
    category: 'SAFETY DRILL',
    title: 'Industrial Safety & Fire Fighting Simulation',
    description: 'Mandatory workshop evacuation drills and hazardous materials management conducted by J&K Fire & Emergency Services.',
    time: '02:00 PM - 4:30 PM',
    venue: 'Central Courtyard & Mechanical Wing'
  }
];

export const initialPrincipalDesk: PrincipalDeskInfo = {
  name: 'Er. Ravinder Singh Bhatti',
  designation: 'Principal / Superintendent',
  institute: 'Govt ITI Udhampur (J&K)',
  photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  quote: '"I extend my warmest greetings to all prospective trainees, parents, and industry patrons. In today\'s dynamic engineering landscape, hands-on technical craftsmanship is the absolute bedrock of India\'s self-reliant economic destiny."',
  slokaHindi: '“उद्यमेन हि सिध्यन्ति कार्याणि न मनोरथैः”',
  slokaEnglish: 'Tasks are fulfilled by sincere endeavor and technical action, not mere idle wishes.',
  fullMessage: 'Our mission at ITI Udhampur is to bridge academic theories with rigorous workshop practice. We transform enthusiastic rural and urban learners into precision craftsmen ready for the world’s most demanding industries. With modern CNC equipment, computer laboratories, and partnerships with leading manufacturing firms under the Dual System of Training (DST), we ensure our graduates step confidently into rewarding careers.'
};

export const initialTrades: TradeItem[] = [
  // IT Sector
  {
    id: 'trade-copa',
    name: 'COPA (Computer Operator)',
    code: 'CTS-01',
    sector: 'it',
    duration: '1 Yr',
    eligibility: '10th Pass',
    affiliation: 'NCVT',
    seats: 48,
    description: 'Comprehensive IT training in Python, Web Scripting, Database Management, and Cloud Office tools.'
  },
  {
    id: 'trade-deo',
    name: 'Data Entry Operator',
    code: 'CTS-02',
    sector: 'it',
    duration: '6 Months',
    eligibility: '10th Pass',
    affiliation: 'SCVT',
    seats: 24,
    description: 'Fast-track training in high-speed numeric typing, office spreadsheet automation, and e-governance document handling.'
  },
  {
    id: 'trade-electronics',
    name: 'Electronics Mechanic',
    code: 'CTS-03',
    sector: 'it',
    duration: '2 Yrs',
    eligibility: '10th Pass',
    affiliation: 'NCVT',
    seats: 24,
    description: 'Hands-on hardware troubleshooting, PCB soldering, microcontrollers, SMD components, and consumer electronic repairs.'
  },

  // Heavy Industry & Machinery
  {
    id: 'trade-electrician',
    name: 'Electrician (NCVT)',
    code: 'CTS-04',
    sector: 'engineering',
    duration: '2 Yrs',
    eligibility: '10th Pass',
    affiliation: 'NCVT',
    seats: 40,
    description: 'Master commercial power distribution, three-phase transformers, AC/DC motors, solar invertors, and PLC panels.'
  },
  {
    id: 'trade-plumber-ncvt',
    name: 'Plumber (NCVT)',
    code: 'CTS-05',
    sector: 'engineering',
    duration: '1 Yr',
    eligibility: '8th Pass',
    affiliation: 'NCVT',
    seats: 24,
    description: 'Sanitary plumbing, pressure hydro-testing, solar water heater installations, and modern civic piping networks.'
  },
  {
    id: 'trade-mmv',
    name: 'Mechanic Motor Vehicle (MMV)',
    code: 'CTS-06',
    sector: 'engineering',
    duration: '2 Yrs',
    eligibility: '10th Pass',
    affiliation: 'NCVT',
    seats: 24,
    description: 'Engine overhaul, MPFI fuel systems, ABS braking, EV powertrain diagnostics, and automotive computerized tuning.'
  },
  {
    id: 'trade-welder',
    name: 'Welder (GMAW / GTAW)',
    code: 'CTS-07',
    sector: 'engineering',
    duration: '1 Yr',
    eligibility: '8th Pass',
    affiliation: 'NCVT',
    seats: 20,
    description: 'Argon TIG welding, MIG/MAG gas shielded arc welding, pipe welding 6G position, and plasma arc cutting techniques.'
  },

  // Apparel & Civil Crafts
  {
    id: 'trade-cosmetology',
    name: 'Cosmetology',
    code: 'CTS-08',
    sector: 'consumer',
    duration: '1 Yr',
    eligibility: '10th Pass',
    affiliation: 'NCVT',
    seats: 24,
    description: 'Advanced wellness therapy, therapeutic skin care, professional salon management, and chemical hair styling.'
  },
  {
    id: 'trade-draughtsman',
    name: 'Draughtsman (Civil)',
    code: 'CTS-09',
    sector: 'consumer',
    duration: '2 Yrs',
    eligibility: '10th Pass',
    affiliation: 'NCVT',
    seats: 24,
    description: 'AutoCAD architectural drafting, BIM building modeling, total station land surveying, and structural plan estimation.'
  },
  {
    id: 'trade-plumber-civil',
    name: 'Plumber',
    code: 'CTS-10',
    sector: 'consumer',
    duration: '1 Yr',
    eligibility: '8th Pass',
    affiliation: 'SCVT',
    seats: 20,
    description: 'Modern sanitary fixtures, drainage hydraulics, leak detection, and municipal water supply connections.'
  },
  {
    id: 'trade-sewing',
    name: 'Sewing Technology (Dress Making)',
    code: 'CTS-11',
    sector: 'consumer',
    duration: '1 Yr',
    eligibility: '8th Pass',
    affiliation: 'NCVT',
    seats: 24,
    description: 'Garment pattern drafting, motorized industrial sewing machine operation, fashion grading, and textile finishing.'
  }
];

export const initialWhyChoose: WhyChoosePoint[] = [
  {
    id: 'wc-1',
    title: '100% Practical Training',
    description: 'Full-scale industrial workshops equipped with live CNC machines, lathe beds, and automotive overhaul simulators.',
    icon: 'Wrench'
  },
  {
    id: 'wc-2',
    title: 'Govt Recognized',
    description: 'NCVT & SCVT certificates recognized by Central PSUs, Railways, Defense, and international employer councils.',
    icon: 'ShieldCheck'
  },
  {
    id: 'wc-3',
    title: 'Certified Faculty',
    description: 'Craft Instructor Training Scheme (CITS) certified instructors with over 15+ years of practical sector expertise.',
    icon: 'GraduationCap'
  },
  {
    id: 'wc-4',
    title: 'Industry Placements',
    description: 'Dedicated training and placement cell organizing regular campus interviews with Maruti Suzuki, Tata, and NHPC.',
    icon: 'Briefcase'
  },
  {
    id: 'wc-5',
    title: 'Scholarship Support',
    description: 'Post-Matric, PMSSS, and Pragati scholarships with direct benefit transfer credit straight to trainee bank accounts.',
    icon: 'IndianRupee'
  },
  {
    id: 'wc-6',
    title: 'Campus Environment',
    description: 'Peaceful green setting along Dhar Road, near Subhash Stadium with smart classrooms, digital library, and sports facility.',
    icon: 'Trees'
  }
];

export const initialCitizenHub: CitizenHubItem[] = [
  {
    id: 'hub-1',
    title: 'Institute Tenders',
    subtitle: 'E-Procurement',
    icon: 'FileSpreadsheet',
    link: '#tenders'
  },
  {
    id: 'hub-2',
    title: 'Right to Info',
    subtitle: 'RTI Act 2005',
    icon: 'Scale',
    link: '#rti'
  },
  {
    id: 'hub-3',
    title: 'Downloads',
    subtitle: 'Forms & Circulars',
    icon: 'Download',
    link: '#circulars'
  },
  {
    id: 'hub-4',
    title: 'Photo Gallery',
    subtitle: 'Campus Workshops',
    icon: 'Camera',
    link: '#gallery'
  },
  {
    id: 'hub-5',
    title: 'NCVT MIS Portal',
    subtitle: 'Marks Sheets',
    icon: 'Award',
    link: 'https://ncvtmis.gov.in'
  },
  {
    id: 'hub-6',
    title: 'Grievance Cell',
    subtitle: 'Anti-Ragging / Redress',
    icon: 'HeartHandshake',
    link: '#grievance'
  }
];

export const initialNationalPortals: NationalPortal[] = [
  { id: 'p1', name: 'NCVT MIS', subText: 'Trainee Profile', url: 'https://ncvtmis.gov.in' },
  { id: 'p2', name: 'DGT India', subText: 'MSDE Delhi', url: 'https://dgt.gov.in' },
  { id: 'p3', name: 'Skill India', subText: 'Digital Hub', url: 'https://skillindiadigital.gov.in' },
  { id: 'p4', name: 'NAPS Portal', subText: 'Apprenticeship', url: 'https://apprenticeshipindia.gov.in' },
  { id: 'p5', name: 'NIMI', subText: 'Instructional Media', url: 'https://nimi.gov.in' },
  { id: 'p6', name: 'Digital India', subText: 'MeitY Services', url: 'https://digitalindia.gov.in' },
  { id: 'p7', name: 'DSD J&K', subText: 'State Directorate', url: 'https://jkdsd.in' },
  { id: 'p8', name: 'NCS Portal', subText: 'Career Services', url: 'https://ncs.gov.in' }
];

export const initialGalleryPhotos: GalleryPhoto[] = [
  {
    id: 'gal-1',
    title: 'Modern CNC Milling & Lathe Workshop',
    category: 'Workshops',
    imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80',
    caption: 'Precision engineering trainees operating advanced computer numerical control equipment under faculty guidance.',
    dateUploaded: '14-04-2026'
  },
  {
    id: 'gal-2',
    title: 'Automotive Engine Overhaul Bay (MMV Trade)',
    category: 'Workshops',
    imageUrl: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=1000&q=80',
    caption: 'Trainees conducting multi-point engine timing and transmission diagnosis on modern four-wheeler test beds.',
    dateUploaded: '10-04-2026'
  },
  {
    id: 'gal-3',
    title: 'Smart Computer Center & COPA Lab',
    category: 'Labs',
    imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1000&q=80',
    caption: 'High-speed gigabit networked computer terminal room for CTS software engineering and web application drills.',
    dateUploaded: '02-04-2026'
  },
  {
    id: 'gal-4',
    title: 'Electrician Three-Phase Panel Testing Bench',
    category: 'Labs',
    imageUrl: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=1000&q=80',
    caption: 'Wiring distribution boards, circuit breakers, and industrial motor starter control enclosures.',
    dateUploaded: '28-03-2026'
  },
  {
    id: 'gal-5',
    title: 'Dedicated Women Wing - Dress Making Workshop',
    category: 'Women Wing',
    imageUrl: 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=1000&q=80',
    caption: 'Specialized sewing technology and fashion designing floor empowering regional female artisans.',
    dateUploaded: '20-03-2026'
  },
  {
    id: 'gal-6',
    title: 'Annual Campus Tree Plantation & Eco Drive',
    category: 'Campus',
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=1000&q=80',
    caption: 'Principal, instructors, and cadets planting saplings across the serene Dhar Road perimeter.',
    dateUploaded: '12-03-2026'
  }
];

export const initialTenders: TenderNotice[] = [
  {
    id: 'tnd-1',
    tenderId: '2026_DSD_99412',
    title: 'E-Tender Notice for Supply & Commissioning of CNC Simulation Software & Lathe Tooling for Modern Workshop',
    publishedDate: '15-04-2026',
    closingDate: '12-05-2026',
    estimatedValue: '₹ 18,50,000/-',
    tenderDocSize: 'PDF (2.4 MB)',
    status: 'ACTIVE'
  },
  {
    id: 'tnd-2',
    tenderId: '2026_DSD_98104',
    title: 'Annual Rate Contract for Supply of Raw Materials, Mild Steel Flats & Welding Electrodes for CTS Session 2026-27',
    publishedDate: '08-04-2026',
    closingDate: '29-04-2026',
    estimatedValue: '₹ 8,20,000/-',
    tenderDocSize: 'PDF (1.6 MB)',
    status: 'ACTIVE'
  },
  {
    id: 'tnd-3',
    tenderId: '2026_DSD_97442',
    title: 'Comprehensive Maintenance Contract (CMC) for Heavy Hydraulic Automotive Car Hoists & Wheel Balancers',
    publishedDate: '24-03-2026',
    closingDate: '18-04-2026',
    estimatedValue: '₹ 3,75,000/-',
    tenderDocSize: 'PDF (980 KB)',
    status: 'ACTIVE'
  }
];

export const initialRtiOfficers: RtiOfficer[] = [
  {
    designation: 'Public Information Officer (PIO)',
    name: 'Er. Rajesh Kumar Sharma',
    officialRole: 'Senior Workshop Superintendent',
    phone: '+91 1992 270428 (Ext. 104)',
    email: 'pio-itiudhampur@jk.gov.in',
    officeAddress: 'Administrative Wing, Room No. 04, Govt ITI Udhampur'
  },
  {
    designation: 'First Appellate Authority (FAA)',
    name: 'Er. Ravinder Singh Bhatti',
    officialRole: 'Principal / Superintendent',
    phone: '+91 1992 270428 (Ext. 101)',
    email: 'itiudhampur@gmail.com',
    officeAddress: "Principal's Secretariat, Govt ITI Udhampur"
  }
];

export const initialFacilities: FacilityItem[] = [
  {
    id: 'fac-1',
    name: 'Precision CNC Machining & Turning Center',
    category: 'Workshops',
    capacity: '24 Trainees per Shift',
    machinery: '2 CNC Lathes, 1 CNC Milling Center, 12 Simulation Desktops, Precision Verniers',
    description: 'State-of-the-art manufacturing lab imparting industrial CAD/CAM g-code programming and precision metal finishing.'
  },
  {
    id: 'fac-2',
    name: 'Automotive Engine Diagnostics & EV Powertrain Bay',
    category: 'Workshops',
    capacity: '20 Trainees per Shift',
    machinery: 'Four-Wheeler Hydraulic Hoists, Electronic Injector Test Bench, OBD-II Scanners',
    description: 'Equipped for MMV and Diesel Mechanic trainees to perform engine teardown, multi-point transmission overhaul, and sensor tuning.'
  },
  {
    id: 'fac-3',
    name: 'Smart Gigabit Computer Center & COPA Lab',
    category: 'Smart Labs',
    capacity: '48 Computer Terminals',
    machinery: 'Core i7 Desktops, 100 Mbps Dedicated Optical Leased Line, Smart Touch Interactive Board',
    description: 'Air-conditioned digital computing facility for database administration, Python programming, and web development.'
  },
  {
    id: 'fac-4',
    name: 'High-Voltage Electrical Transmission Testing Bench',
    category: 'Smart Labs',
    capacity: '24 Trainees per Shift',
    machinery: '3-Phase Motor Generator Sets, Synchronous Alternators, PLC Demonstration Panels',
    description: 'Advanced testing infrastructure for Electrician trade trainees under national safety protocols.'
  },
  {
    id: 'fac-5',
    name: 'Solar Rooftop & Renewable Energy Simulation Rig',
    category: 'Renewable Energy',
    capacity: '16 Trainees per Shift',
    machinery: 'Grid-Tied Micro Inverters, Solar Photovoltaic Angle Array, Battery Storage Banks',
    description: 'Established under PM Surya Ghar Yojana for training certified technicians in clean solar energy deployment.'
  }
];

export const initialMandatoryDisclosures: MandatoryDisclosureItem[] = [
  {
    id: 'md-1',
    title: 'DGT Order of Continuous Affiliation for CTS Engineering Trades',
    category: 'Affiliation Order',
    docNumber: 'DGT-12/1/2025-TC/J&K',
    approvalDate: '15-01-2025',
    fileSize: 'PDF (1.8 MB)'
  },
  {
    id: 'md-2',
    title: 'PWD Structural & Building Safety Fitness Certificate',
    category: 'Building Safety',
    docNumber: 'EE/R&B/UDH/2026/1029',
    approvalDate: '04-03-2026',
    fileSize: 'PDF (650 KB)'
  },
  {
    id: 'md-3',
    title: 'Fire Safety Certificate & Workshop NOC from Fire & Emergency Services',
    category: 'Fire NOC',
    docNumber: 'F&ES/UDH/NOC/2026/88',
    approvalDate: '18-02-2026',
    fileSize: 'PDF (720 KB)'
  },
  {
    id: 'md-4',
    title: 'Sanctioned Faculty Strength & CITS Certified Instructor Roster',
    category: 'Staff Structure',
    docNumber: 'DSD/Est/Gaz/2026/410',
    approvalDate: '01-04-2026',
    fileSize: 'PDF (1.1 MB)'
  }
];
