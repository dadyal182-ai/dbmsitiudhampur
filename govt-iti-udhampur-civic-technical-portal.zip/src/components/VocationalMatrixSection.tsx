import React from 'react';
import { usePortal } from '../context/PortalContext';
import { Monitor, Cpu, Scissors, ArrowRight, BookOpen, PlusCircle } from 'lucide-react';
import { TradeItem } from '../types';

export const VocationalMatrixSection: React.FC = () => {
  const { trades, isAdmin, openAdminTab, openModal } = usePortal();

  // Filter trades by sector
  const itTrades = trades.filter((t) => t.sector === 'it');
  const engTrades = trades.filter((t) => t.sector === 'engineering');
  const consumerTrades = trades.filter((t) => t.sector === 'consumer');

  return (
    <section id="trades" className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#06038d] bg-[#e2e7ff] px-3 py-1 rounded-xs inline-block mb-2">
            VOCATIONAL MATRIX
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Available Sectors of the Institute
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-2">
            Explore our Craftsmen Training Scheme (CTS) trades organized across three high-demand industrial sectors.
          </p>

          {isAdmin && (
            <div className="mt-3">
              <button
                onClick={() => openAdminTab('trades')}
                className="inline-flex items-center gap-1.5 text-xs bg-[#004f28] text-white px-3 py-1 rounded-xs font-semibold cursor-pointer shadow-xs"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Add / Manage Trades</span>
              </button>
            </div>
          )}
        </div>

        {/* 3 Sector Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* 1. IT & Electronics */}
          <div className="bg-[#faf8ff] border border-slate-200 rounded-xs p-6 shadow-xs flex flex-col justify-between">
            <div>
              {/* Sector Icon */}
              <div className="w-10 h-10 rounded-xs bg-[#004f28] text-white flex items-center justify-center mb-4 shadow-xs">
                <Monitor className="w-5 h-5" />
              </div>

              <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider">
                INFORMATION TECHNOLOGY
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5 mb-2">
                IT-ITeS &amp; Electronics Sector
              </h3>

              <p className="text-xs text-slate-600 leading-relaxed mb-5">
                Encompasses cutting-edge computing competencies, office administration tools, network architecture, and Internet-of-Things automation.
              </p>

              {/* Trades List */}
              <div className="divide-y divide-slate-200 border-t border-b border-slate-200 my-4">
                {itTrades.map((trade) => (
                  <div
                    key={trade.id}
                    onClick={() => openModal('view-trade', trade)}
                    className="py-2.5 flex items-center justify-between text-xs cursor-pointer group hover:bg-white/80 px-1 rounded-xs transition-colors"
                  >
                    <span className="font-semibold text-slate-900 group-hover:text-[#004f28]">
                      {trade.name}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono shrink-0">
                      {trade.duration} • {trade.eligibility}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Button */}
            <div className="pt-2">
              <button
                onClick={() => openModal('trades-syllabus', 'it')}
                className="w-full bg-[#004f28] hover:bg-[#046a38] text-white py-2.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>VIEW IT TRADES SYLLABUS</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* 2. Heavy Industry & Machinery */}
          <div className="bg-[#faf8ff] border border-slate-200 rounded-xs p-6 shadow-xs flex flex-col justify-between">
            <div>
              {/* Sector Icon */}
              <div className="w-10 h-10 rounded-xs bg-[#06038d] text-white flex items-center justify-center mb-4 shadow-xs">
                <Cpu className="w-5 h-5" />
              </div>

              <span className="text-[10px] uppercase font-bold text-[#06038d] tracking-wider">
                HEAVY INDUSTRY &amp; MACHINERY
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5 mb-2">
                Power &amp; Capital Goods Sector
              </h3>

              <p className="text-xs text-slate-600 leading-relaxed mb-5">
                Industrial engineering backbones: electrical transmission, precision fitting, automotive mechanics, fabrication, and lathe turning.
              </p>

              {/* Trades List */}
              <div className="divide-y divide-slate-200 border-t border-b border-slate-200 my-4">
                {engTrades.map((trade) => (
                  <div
                    key={trade.id}
                    onClick={() => openModal('view-trade', trade)}
                    className="py-2.5 flex items-center justify-between text-xs cursor-pointer group hover:bg-white/80 px-1 rounded-xs transition-colors"
                  >
                    <span className="font-semibold text-slate-900 group-hover:text-[#06038d]">
                      {trade.name}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono shrink-0">
                      {trade.duration} • {trade.eligibility}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Button */}
            <div className="pt-2">
              <button
                onClick={() => openModal('trades-syllabus', 'engineering')}
                className="w-full bg-[#06038d] hover:bg-[#2f33a8] text-white py-2.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>VIEW ENGINEERING TRADES</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* 3. Apparel & Civil Crafts */}
          <div className="bg-[#faf8ff] border border-slate-200 rounded-xs p-6 shadow-xs flex flex-col justify-between">
            <div>
              {/* Sector Icon */}
              <div className="w-10 h-10 rounded-xs bg-[#a73a00] text-white flex items-center justify-center mb-4 shadow-xs">
                <Scissors className="w-5 h-5" />
              </div>

              <span className="text-[10px] uppercase font-bold text-[#a73a00] tracking-wider">
                APPAREL &amp; CIVIL CRAFTS
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5 mb-2">
                Construction, Solar &amp; Apparel
              </h3>

              <p className="text-xs text-slate-600 leading-relaxed mb-5">
                Civil architectural draftsmanship, sanitary plumbing systems, rooftop solar generation, and garment manufacturing technologies.
              </p>

              {/* Trades List */}
              <div className="divide-y divide-slate-200 border-t border-b border-slate-200 my-4">
                {consumerTrades.map((trade) => (
                  <div
                    key={trade.id}
                    onClick={() => openModal('view-trade', trade)}
                    className="py-2.5 flex items-center justify-between text-xs cursor-pointer group hover:bg-white/80 px-1 rounded-xs transition-colors"
                  >
                    <span className="font-semibold text-slate-900 group-hover:text-[#a73a00]">
                      {trade.name}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono shrink-0">
                      {trade.duration} • {trade.eligibility}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Button */}
            <div className="pt-2">
              <button
                onClick={() => openModal('trades-syllabus', 'consumer')}
                className="w-full bg-[#fd661d] hover:bg-[#a73a00] text-white py-2.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>VIEW CONSUMER TRADES</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
