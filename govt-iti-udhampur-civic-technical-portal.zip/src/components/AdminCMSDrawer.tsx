import React, { useState } from 'react';
import { usePortal } from '../context/PortalContext';
import {
  X,
  FileText,
  Image as ImageIcon,
  BookOpen,
  Calendar,
  Building,
  UserCheck,
  Megaphone,
  Upload,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Save,
  RefreshCw,
  Eye,
  FileSpreadsheet,
  Layers,
  HelpCircle,
  FolderPlus,
  Scale
} from 'lucide-react';
import { OrderCategory, EventCategory, SectorType } from '../types';

export const AdminCMSDrawer: React.FC = () => {
  const {
    isEditDrawerOpen,
    setIsEditDrawerOpen,
    activeAdminTab,
    openAdminTab,
    institution,
    updateInstitution,
    hero,
    updateHero,
    principalDesk,
    updatePrincipalDesk,
    orders,
    addOrder,
    updateOrder,
    deleteOrder,
    events,
    addEvent,
    updateEvent,
    deleteEvent,
    trades,
    addTrade,
    updateTrade,
    deleteTrade,
    gallery,
    addPhoto,
    deletePhoto,
    tickerAlerts,
    updateTickerAlerts,
    tenders,
    addTender,
    deleteTender,
    facilities,
    addFacility,
    deleteFacility,
    mandatoryDisclosures,
    addMandatoryDisclosure,
    deleteMandatoryDisclosure,
    rtiOfficers,
    updateRtiOfficer
  } = usePortal();

  // Status notification state
  const [saveNotice, setSaveNotice] = useState<string | null>(null);

  const showSuccess = (msg: string) => {
    setSaveNotice(msg);
    setTimeout(() => setSaveNotice(null), 3000);
  };

  // --- Orders State ---
  const [newOrderTitle, setNewOrderTitle] = useState('');
  const [newOrderRef, setNewOrderRef] = useState('');
  const [newOrderDate, setNewOrderDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [newOrderCat, setNewOrderCat] = useState<OrderCategory>('URGENT');
  const [newOrderAuthority, setNewOrderAuthority] = useState('Directorate of Technical Education, J&K');
  const [newOrderDesc, setNewOrderDesc] = useState('');
  const [newOrderFileName, setNewOrderFileName] = useState('');
  const [newOrderFileSize, setNewOrderFileSize] = useState('PDF (1.2 MB)');
  const [editingOrderId, setEditingOrderId] = useState<string | null>(null);

  // File upload handler for Orders
  const handleOrderFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setNewOrderFileName(file.name);
      const sizeMB = (file.size / (1024 * 1024)).toFixed(1);
      setNewOrderFileSize(`PDF (${sizeMB} MB)`);
      if (!newOrderTitle) {
        setNewOrderTitle(file.name.replace(/\.[^/.]+$/, ''));
      }
    }
  };

  const handleSaveOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOrderTitle.trim()) return;

    if (editingOrderId) {
      updateOrder(editingOrderId, {
        title: newOrderTitle,
        refNo: newOrderRef || 'ITIU/Order/2026',
        date: newOrderDate,
        category: newOrderCat,
        issuingAuthority: newOrderAuthority,
        description: newOrderDesc,
        fileSize: newOrderFileSize
      });
      showSuccess('Order updated successfully!');
      setEditingOrderId(null);
    } else {
      addOrder({
        title: newOrderTitle,
        refNo: newOrderRef || `ITIU/Order/2026/${Math.floor(100 + Math.random() * 900)}`,
        date: newOrderDate,
        category: newOrderCat,
        issuingAuthority: newOrderAuthority,
        description: newOrderDesc,
        fileSize: newOrderFileSize
      });
      showSuccess('New order uploaded successfully!');
    }

    // Reset form
    setNewOrderTitle('');
    setNewOrderRef('');
    setNewOrderDesc('');
    setNewOrderFileName('');
  };

  const startEditOrder = (o: any) => {
    setEditingOrderId(o.id);
    setNewOrderTitle(o.title);
    setNewOrderRef(o.refNo);
    setNewOrderDate(o.date);
    setNewOrderCat(o.category);
    setNewOrderAuthority(o.issuingAuthority);
    setNewOrderDesc(o.description || '');
    setNewOrderFileSize(o.fileSize);
  };

  // --- Photos State ---
  const [heroPhotoUrl, setHeroPhotoUrl] = useState(hero.heroPhotoUrl);
  const [heroBadge, setHeroBadge] = useState(hero.heroPhotoBadge);
  const [heroCaption, setHeroCaption] = useState(hero.heroPhotoCaption);

  const [principalPhotoUrl, setPrincipalPhotoUrl] = useState(principalDesk.photoUrl);

  const [newPhotoTitle, setNewPhotoTitle] = useState('');
  const [newPhotoCat, setNewPhotoCat] = useState<'Workshops' | 'Campus' | 'Labs' | 'Events' | 'Women Wing'>('Workshops');
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [newPhotoCaption, setNewPhotoCaption] = useState('');

  const handleHeroPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setHeroPhotoUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePrincipalPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPrincipalPhotoUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGalleryPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setNewPhotoUrl(event.target.result as string);
          if (!newPhotoTitle) {
            setNewPhotoTitle(file.name.replace(/\.[^/.]+$/, ''));
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveHeroPhoto = () => {
    updateHero({
      heroPhotoUrl,
      heroPhotoBadge: heroBadge,
      heroPhotoCaption: heroCaption
    });
    showSuccess('Campus hero photo updated!');
  };

  const handleSavePrincipalPhoto = () => {
    updatePrincipalDesk({ photoUrl: principalPhotoUrl });
    showSuccess('Principal photo updated!');
  };

  const handleAddGalleryPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPhotoUrl.trim() || !newPhotoTitle.trim()) return;
    addPhoto({
      title: newPhotoTitle,
      category: newPhotoCat,
      imageUrl: newPhotoUrl,
      caption: newPhotoCaption || newPhotoTitle
    });
    setNewPhotoTitle('');
    setNewPhotoUrl('');
    setNewPhotoCaption('');
    showSuccess('New workshop photo added to gallery!');
  };

  // --- Trade State ---
  const [newTradeName, setNewTradeName] = useState('');
  const [newTradeSector, setNewTradeSector] = useState<SectorType>('it');
  const [newTradeDuration, setNewTradeDuration] = useState('1 Yr');
  const [newTradeEligibility, setNewTradeEligibility] = useState('10th Pass');
  const [newTradeAffiliation, setNewTradeAffiliation] = useState<'NCVT' | 'SCVT'>('NCVT');
  const [newTradeSeats, setNewTradeSeats] = useState(24);
  const [newTradeDesc, setNewTradeDesc] = useState('');

  const handleAddTrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTradeName.trim()) return;
    addTrade({
      name: newTradeName,
      sector: newTradeSector,
      duration: newTradeDuration,
      eligibility: newTradeEligibility,
      affiliation: newTradeAffiliation,
      seats: Number(newTradeSeats) || 24,
      description: newTradeDesc
    });
    setNewTradeName('');
    setNewTradeDesc('');
    showSuccess('Vocational trade added successfully!');
  };

  // --- Events State ---
  const [newEventDay, setNewEventDay] = useState('10');
  const [newEventMonthYear, setNewEventMonthYear] = useState("JUN '26");
  const [newEventCat, setNewEventCat] = useState<EventCategory>('WORKSHOP');
  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventDesc, setNewEventDesc] = useState('');
  const [newEventVenue, setNewEventVenue] = useState('ITI Main Campus, Udhampur');

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle.trim()) return;
    addEvent({
      day: newEventDay,
      monthYear: newEventMonthYear,
      category: newEventCat,
      title: newEventTitle,
      description: newEventDesc,
      venue: newEventVenue
    });
    setNewEventTitle('');
    setNewEventDesc('');
    showSuccess('Upcoming event scheduled!');
  };

  // --- Tenders State ---
  const [newTenderId, setNewTenderId] = useState('');
  const [newTenderTitle, setNewTenderTitle] = useState('');
  const [newTenderPublished, setNewTenderPublished] = useState(() => new Date().toISOString().slice(0, 10));
  const [newTenderClosing, setNewTenderClosing] = useState('15-05-2026');
  const [newTenderValue, setNewTenderValue] = useState('₹ 10,00,000/-');
  const [newTenderDocSize, setNewTenderDocSize] = useState('PDF (1.8 MB)');

  const handleAddTender = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTenderTitle.trim()) return;
    addTender({
      tenderId: newTenderId || `2026_DSD_${Math.floor(10000 + Math.random() * 90000)}`,
      title: newTenderTitle,
      publishedDate: newTenderPublished,
      closingDate: newTenderClosing,
      estimatedValue: newTenderValue,
      tenderDocSize: newTenderDocSize,
      status: 'ACTIVE'
    });
    setNewTenderTitle('');
    setNewTenderId('');
    showSuccess('New E-Tender published successfully!');
  };

  // --- Facilities State ---
  const [newFacName, setNewFacName] = useState('');
  const [newFacCat, setNewFacCat] = useState<'Workshops' | 'Smart Labs' | 'Hostel & Amenities' | 'Renewable Energy'>('Workshops');
  const [newFacCapacity, setNewFacCapacity] = useState('24 Trainees');
  const [newFacMachinery, setNewFacMachinery] = useState('');
  const [newFacDesc, setNewFacDesc] = useState('');

  const handleAddFacility = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFacName.trim()) return;
    addFacility({
      name: newFacName,
      category: newFacCat,
      capacity: newFacCapacity,
      machinery: newFacMachinery || 'Industrial toolkits and certified testing meters',
      description: newFacDesc || 'Fully equipped practical learning unit.'
    });
    setNewFacName('');
    setNewFacMachinery('');
    setNewFacDesc('');
    showSuccess('New facility / workshop registered!');
  };

  // --- Disclosures State ---
  const [newDiscTitle, setNewDiscTitle] = useState('');
  const [newDiscCat, setNewDiscCat] = useState<'Affiliation Order' | 'Building Safety' | 'Fire NOC' | 'Staff Structure'>('Affiliation Order');
  const [newDiscDocNo, setNewDiscDocNo] = useState('');
  const [newDiscDate, setNewDiscDate] = useState('15-03-2026');

  const handleAddDisclosure = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDiscTitle.trim()) return;
    addMandatoryDisclosure({
      title: newDiscTitle,
      category: newDiscCat,
      docNumber: newDiscDocNo || `DSD/Doc/${Math.floor(100 + Math.random() * 900)}`,
      approvalDate: newDiscDate,
      fileSize: 'PDF (1.2 MB)'
    });
    setNewDiscTitle('');
    setNewDiscDocNo('');
    showSuccess('Mandatory compliance disclosure uploaded!');
  };

  // --- Institutional / Hero Form State ---
  const [instState, setInstState] = useState(institution);
  const [heroState, setHeroState] = useState(hero);
  const [principalState, setPrincipalState] = useState(principalDesk);
  const [alertsState, setAlertsState] = useState<string[]>(tickerAlerts);
  const [newTickerText, setNewTickerText] = useState('');

  if (!isEditDrawerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-4xl h-full shadow-2xl flex flex-col overflow-hidden border-l border-slate-300">
        
        {/* Top Header */}
        <div className="bg-[#004f28] text-white p-4 flex items-center justify-between border-b border-[#046a38]">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-xs">
              <Building className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold leading-tight">ITI Portal Content Management System (CMS)</h2>
              <p className="text-xs text-white/80">Govt Industrial Training Institute, Udhampur (J&amp;K)</p>
            </div>
          </div>
          <button
            onClick={() => setIsEditDrawerOpen(false)}
            className="text-white/80 hover:text-white p-1.5 rounded hover:bg-white/10 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Floating Notification */}
        {saveNotice && (
          <div className="bg-emerald-600 text-white px-4 py-2 text-xs font-semibold flex items-center justify-between animate-in slide-in-from-top duration-200 shadow-md">
            <span className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" /> {saveNotice}
            </span>
            <button onClick={() => setSaveNotice(null)} className="text-white/80 hover:text-white">✕</button>
          </div>
        )}

        {/* Tab Navigation Ribbon */}
        <div className="bg-slate-100 border-b border-slate-200 px-3 flex flex-wrap gap-1 text-xs font-medium overflow-x-auto">
          {[
            { id: 'orders', label: 'Orders & Circulars', icon: FileText, count: orders.length },
            { id: 'tenders', label: 'E-Tenders', icon: FileSpreadsheet, count: tenders.length },
            { id: 'photos', label: 'Update Photos', icon: ImageIcon, count: gallery.length },
            { id: 'trades', label: 'Trades & Courses', icon: BookOpen, count: trades.length },
            { id: 'events', label: 'Events & Calendar', icon: Calendar, count: events.length },
            { id: 'facilities', label: 'Workshops & Labs', icon: Layers, count: facilities.length },
            { id: 'disclosures', label: 'RTI & Disclosures', icon: Scale, count: mandatoryDisclosures.length },
            { id: 'hero', label: 'Hero & Stats', icon: Megaphone },
            { id: 'principal', label: "Principal's Desk", icon: UserCheck },
            { id: 'institution', label: 'Institute Info & Contact', icon: Building },
            { id: 'alerts', label: 'Marquee Alerts', icon: RefreshCw, count: alertsState.length },
            { id: 'guide', label: '⚡ Upload Directory', icon: HelpCircle },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeAdminTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => openAdminTab(tab.id)}
                className={`py-2.5 px-3 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'border-[#004f28] text-[#004f28] font-bold bg-white'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#004f28]' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                    isActive ? 'bg-[#004f28] text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50">

          {/* 1. ORDERS & CIRCULARS */}
          {activeAdminTab === 'orders' && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Upload className="w-4 h-4 text-[#004f28]" />
                    {editingOrderId ? 'Edit Existing Circular / Order' : 'Upload New Order / Notification'}
                  </h3>
                  {editingOrderId && (
                    <button
                      onClick={() => {
                        setEditingOrderId(null);
                        setNewOrderTitle('');
                        setNewOrderRef('');
                        setNewOrderDesc('');
                      }}
                      className="text-xs text-slate-500 hover:text-slate-700 underline"
                    >
                      Cancel Edit
                    </button>
                  )}
                </div>

                <form onSubmit={handleSaveOrder} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Order / Notification Title *
                    </label>
                    <input
                      type="text"
                      value={newOrderTitle}
                      onChange={(e) => setNewOrderTitle(e.target.value)}
                      placeholder="e.g. Schedule of Counseling for Craftsmen Training Scheme 2026-27"
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs focus:ring-1 focus:ring-[#004f28] focus:border-[#004f28]"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Reference Number
                      </label>
                      <input
                        type="text"
                        value={newOrderRef}
                        onChange={(e) => setNewOrderRef(e.target.value)}
                        placeholder="ITIU/Adm/2026/842"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Notification Date
                      </label>
                      <input
                        type="text"
                        value={newOrderDate}
                        onChange={(e) => setNewOrderDate(e.target.value)}
                        placeholder="28-04-2026"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Category Tag
                      </label>
                      <select
                        value={newOrderCat}
                        onChange={(e) => setNewOrderCat(e.target.value as OrderCategory)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      >
                        <option value="URGENT">URGENT (Red)</option>
                        <option value="EXAM">EXAM (Purple)</option>
                        <option value="TENDER">TENDER (Blue)</option>
                        <option value="SCHEME">SCHEME (Indigo)</option>
                        <option value="ADMISSION">ADMISSION (Orange)</option>
                        <option value="GENERAL">GENERAL (Slate)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Issuing Authority
                      </label>
                      <input
                        type="text"
                        value={newOrderAuthority}
                        onChange={(e) => setNewOrderAuthority(e.target.value)}
                        placeholder="Admission Committee / NCVT Cell"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Upload Order File (PDF / DOCX)
                      </label>
                      <div className="flex items-center gap-2">
                        <label className="bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 text-xs py-2 px-3 rounded-xs cursor-pointer flex items-center gap-1">
                          <Upload className="w-3.5 h-3.5" />
                          <span>Choose File</span>
                          <input
                            type="file"
                            onChange={handleOrderFileUpload}
                            accept=".pdf,.doc,.docx,.jpg,.png"
                            className="hidden"
                          />
                        </label>
                        <span className="text-[11px] text-slate-500 truncate max-w-[160px]">
                          {newOrderFileName || 'No file selected (uses simulation)'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Brief Description / Directive
                    </label>
                    <textarea
                      value={newOrderDesc}
                      onChange={(e) => setNewOrderDesc(e.target.value)}
                      placeholder="Brief details regarding document guidelines, reporting deadline, or instructions for trainees..."
                      rows={2}
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{editingOrderId ? 'Update Order Record' : 'Publish Order to Live Website'}</span>
                  </button>
                </form>
              </div>

              {/* Existing Orders Table */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-3">
                  Currently Published Orders &amp; Circulars ({orders.length})
                </h4>

                <div className="divide-y divide-slate-100">
                  {orders.map((ord) => (
                    <div key={ord.id} className="py-3 flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-xs ${
                            ord.category === 'URGENT' ? 'bg-red-100 text-red-700' :
                            ord.category === 'EXAM' ? 'bg-purple-100 text-purple-700' :
                            ord.category === 'TENDER' ? 'bg-blue-100 text-blue-700' :
                            ord.category === 'SCHEME' ? 'bg-indigo-100 text-indigo-700' :
                            'bg-slate-100 text-slate-700'
                          }`}>
                            {ord.category}
                          </span>
                          <span className="text-[11px] text-slate-500 font-mono">{ord.date}</span>
                          <span className="text-[11px] text-slate-400">· Ref: {ord.refNo}</span>
                        </div>
                        <p className="text-xs font-medium text-slate-900 leading-snug">{ord.title}</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {ord.fileSize} · {ord.downloadCount} views · Issued by: {ord.issuingAuthority}
                        </p>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => startEditOrder(ord)}
                          className="p-1.5 text-slate-600 hover:text-[#004f28] hover:bg-slate-100 rounded"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Delete order "${ord.title}"?`)) {
                              deleteOrder(ord.id);
                              showSuccess('Order removed.');
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 2. UPDATE PHOTOS */}
          {activeAdminTab === 'photos' && (
            <div className="space-y-6">
              {/* Campus Hero Photo */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h3 className="font-bold text-sm text-slate-900 mb-1 flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-[#a73a00]" />
                  Update Campus Hero Photo (Main Banner)
                </h3>
                <p className="text-xs text-slate-500 mb-4">
                  The primary campus building and workshop photograph displayed alongside the hero introduction.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                  <div>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Upload Image File from Computer
                        </label>
                        <label className="bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-800 text-xs py-2 px-3 rounded-xs cursor-pointer inline-flex items-center gap-2">
                          <Upload className="w-3.5 h-3.5" />
                          <span>Select Photo File (.jpg, .png, .webp)</span>
                          <input
                            type="file"
                            onChange={handleHeroPhotoUpload}
                            accept="image/*"
                            className="hidden"
                          />
                        </label>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Or Paste Direct Image URL
                        </label>
                        <input
                          type="text"
                          value={heroPhotoUrl}
                          onChange={(e) => setHeroPhotoUrl(e.target.value)}
                          className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                          placeholder="https://..."
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Badge Label
                        </label>
                        <input
                          type="text"
                          value={heroBadge}
                          onChange={(e) => setHeroBadge(e.target.value)}
                          className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                          placeholder="CAMPUS LIFE Near District Hospital Udhampur"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Photo Overlay Caption
                        </label>
                        <input
                          type="text"
                          value={heroCaption}
                          onChange={(e) => setHeroCaption(e.target.value)}
                          className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                          placeholder="Modern Workshop Infrastructure & Smart Labs"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={handleSaveHeroPhoto}
                        className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>Save Campus Hero Photo</span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Live Preview:
                    </label>
                    <div className="relative rounded-sm overflow-hidden border border-slate-300 aspect-[4/3] bg-slate-100">
                      <img
                        src={heroPhotoUrl}
                        alt="Hero Preview"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-3 text-white">
                        <span className="text-[10px] uppercase font-bold text-emerald-400">
                          {heroBadge}
                        </span>
                        <p className="text-xs font-bold leading-tight mt-0.5">{heroCaption}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Principal Photo */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h3 className="font-bold text-sm text-slate-900 mb-1 flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-700" />
                  Update Principal / Superintendent Photograph
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center mt-3">
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Upload Principal Photo
                      </label>
                      <label className="bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-800 text-xs py-2 px-3 rounded-xs cursor-pointer inline-flex items-center gap-2">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Choose Portrait Photo</span>
                        <input
                          type="file"
                          onChange={handlePrincipalPhotoUpload}
                          accept="image/*"
                          className="hidden"
                        />
                      </label>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Or Image URL
                      </label>
                      <input
                        type="text"
                        value={principalPhotoUrl}
                        onChange={(e) => setPrincipalPhotoUrl(e.target.value)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={handleSavePrincipalPhoto}
                      className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>Save Principal Photo</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-4">
                    <img
                      src={principalPhotoUrl}
                      alt="Principal Preview"
                      className="w-24 h-28 object-cover rounded-sm border-2 border-slate-300 shadow-xs"
                    />
                    <div className="text-xs text-slate-600">
                      <p className="font-bold text-slate-900">{principalDesk.name}</p>
                      <p className="text-[11px] text-slate-500">{principalDesk.designation}</p>
                      <p className="text-[11px] text-slate-500">{principalDesk.institute}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Upload to Campus Workshop Photo Gallery */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h3 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
                  <Plus className="w-4 h-4 text-[#004f28]" />
                  Add New Photo to Campus Workshop Gallery
                </h3>

                <form onSubmit={handleAddGalleryPhoto} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Photo Title / Subject *
                      </label>
                      <input
                        type="text"
                        value={newPhotoTitle}
                        onChange={(e) => setNewPhotoTitle(e.target.value)}
                        placeholder="e.g. Electrician Lab Transformer Demonstration"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Category
                      </label>
                      <select
                        value={newPhotoCat}
                        onChange={(e) => setNewPhotoCat(e.target.value as any)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      >
                        <option value="Workshops">Workshops</option>
                        <option value="Labs">Labs</option>
                        <option value="Campus">Campus</option>
                        <option value="Events">Events</option>
                        <option value="Women Wing">Women Wing</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Upload Image File
                      </label>
                      <label className="bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-800 text-xs py-2 px-3 rounded-xs cursor-pointer inline-flex items-center gap-2">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Select File from Device</span>
                        <input
                          type="file"
                          onChange={handleGalleryPhotoUpload}
                          accept="image/*"
                          className="hidden"
                        />
                      </label>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Or Image URL
                      </label>
                      <input
                        type="text"
                        value={newPhotoUrl}
                        onChange={(e) => setNewPhotoUrl(e.target.value)}
                        placeholder="https://..."
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Caption / Description
                    </label>
                    <input
                      type="text"
                      value={newPhotoCaption}
                      onChange={(e) => setNewPhotoCaption(e.target.value)}
                      placeholder="Trainees conducting electrical testing..."
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Photo to Gallery</span>
                  </button>
                </form>

                {/* Existing Gallery Photos */}
                <div className="mt-6 pt-4 border-t border-slate-200">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">
                    Existing Gallery Items ({gallery.length})
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {gallery.map(item => (
                      <div key={item.id} className="relative group border border-slate-200 rounded-xs overflow-hidden bg-slate-50">
                        <img
                          src={item.imageUrl}
                          alt={item.title}
                          className="w-full h-24 object-cover"
                        />
                        <div className="p-2">
                          <span className="text-[9px] bg-slate-200 text-slate-700 px-1 py-0.5 rounded-xs font-semibold">
                            {item.category}
                          </span>
                          <p className="text-[11px] font-semibold text-slate-900 truncate mt-1">{item.title}</p>
                        </div>
                        <button
                          onClick={() => {
                            if (window.confirm(`Delete photo "${item.title}"?`)) {
                              deletePhoto(item.id);
                              showSuccess('Photo removed from gallery.');
                            }
                          }}
                          className="absolute top-1 right-1 bg-red-600 hover:bg-red-700 text-white p-1 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                          title="Delete"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 3. TRADES & COURSES */}
          {activeAdminTab === 'trades' && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h3 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-[#004f28]" />
                  Add New Vocational CTS Trade / Course
                </h3>

                <form onSubmit={handleAddTrade} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Trade Name *
                      </label>
                      <input
                        type="text"
                        value={newTradeName}
                        onChange={(e) => setNewTradeName(e.target.value)}
                        placeholder="e.g. Fitter (NCVT) or Solar PV Technician"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Industrial Sector
                      </label>
                      <select
                        value={newTradeSector}
                        onChange={(e) => setNewTradeSector(e.target.value as SectorType)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      >
                        <option value="it">IT-ITeS &amp; Electronics Sector</option>
                        <option value="engineering">Power &amp; Capital Goods Sector (Engineering)</option>
                        <option value="consumer">Construction, Solar &amp; Apparel (Consumer Crafts)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Duration
                      </label>
                      <input
                        type="text"
                        value={newTradeDuration}
                        onChange={(e) => setNewTradeDuration(e.target.value)}
                        placeholder="1 Yr / 2 Yrs / 6 Mos"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Min. Eligibility
                      </label>
                      <input
                        type="text"
                        value={newTradeEligibility}
                        onChange={(e) => setNewTradeEligibility(e.target.value)}
                        placeholder="10th Pass / 8th Pass"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Affiliation
                      </label>
                      <select
                        value={newTradeAffiliation}
                        onChange={(e) => setNewTradeAffiliation(e.target.value as any)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      >
                        <option value="NCVT">NCVT (National)</option>
                        <option value="SCVT">SCVT (State)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Annual Seats
                      </label>
                      <input
                        type="number"
                        value={newTradeSeats}
                        onChange={(e) => setNewTradeSeats(Number(e.target.value))}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Curriculum Summary
                    </label>
                    <textarea
                      value={newTradeDesc}
                      onChange={(e) => setNewTradeDesc(e.target.value)}
                      placeholder="Hands-on workshop skills, machine handling, safety standards..."
                      rows={2}
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Trade to Institutional Matrix</span>
                  </button>
                </form>
              </div>

              {/* Existing Trades List */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-3">
                  Current CTS Trades ({trades.length})
                </h4>
                <div className="divide-y divide-slate-100">
                  {trades.map(t => (
                    <div key={t.id} className="py-2.5 flex items-center justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">{t.name}</span>
                          <span className="text-[10px] font-semibold bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded-xs">
                            {t.sector.toUpperCase()}
                          </span>
                          <span className="text-[10px] font-bold text-[#004f28]">{t.affiliation}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {t.duration} · Min. Qual: {t.eligibility} · {t.seats} Seats
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete trade "${t.name}"?`)) {
                            deleteTrade(t.id);
                            showSuccess('Trade removed.');
                          }
                        }}
                        className="text-slate-400 hover:text-red-600 p-1.5 rounded hover:bg-red-50"
                        title="Delete trade"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 4. EVENTS & CALENDAR */}
          {activeAdminTab === 'events' && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h3 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-[#004f28]" />
                  Schedule Upcoming Event / Campus Activity
                </h3>

                <form onSubmit={handleAddEvent} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Day (e.g. 15)
                      </label>
                      <input
                        type="text"
                        value={newEventDay}
                        onChange={(e) => setNewEventDay(e.target.value)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Month &amp; Year (e.g. MAY '26)
                      </label>
                      <input
                        type="text"
                        value={newEventMonthYear}
                        onChange={(e) => setNewEventMonthYear(e.target.value)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Event Category
                      </label>
                      <select
                        value={newEventCat}
                        onChange={(e) => setNewEventCat(e.target.value as EventCategory)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      >
                        <option value="PLACEMENT MELA">PLACEMENT MELA</option>
                        <option value="CAMPUS FEST">CAMPUS FEST</option>
                        <option value="WORKSHOP">WORKSHOP</option>
                        <option value="SAFETY DRILL">SAFETY DRILL</option>
                        <option value="EXAM">EXAM</option>
                        <option value="SPORTS">SPORTS</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Event Title *
                    </label>
                    <input
                      type="text"
                      value={newEventTitle}
                      onChange={(e) => setNewEventTitle(e.target.value)}
                      placeholder="e.g. Mega Apprenticeship Fair with Central PSUs"
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Venue &amp; Timings
                    </label>
                    <input
                      type="text"
                      value={newEventVenue}
                      onChange={(e) => setNewEventVenue(e.target.value)}
                      placeholder="ITI Main Auditorium / Workshop Bay"
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Description
                    </label>
                    <textarea
                      value={newEventDesc}
                      onChange={(e) => setNewEventDesc(e.target.value)}
                      placeholder="Showcasing live working models..."
                      rows={2}
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Schedule Event</span>
                  </button>
                </form>
              </div>

              {/* Existing Events List */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-3">
                  Scheduled Events ({events.length})
                </h4>
                <div className="divide-y divide-slate-100">
                  {events.map(ev => (
                    <div key={ev.id} className="py-2.5 flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded-xs">
                            {ev.day} {ev.monthYear}
                          </span>
                          <span className="text-[10px] font-bold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded-xs">
                            {ev.category}
                          </span>
                        </div>
                        <p className="text-xs font-bold text-slate-900 mt-1">{ev.title}</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">{ev.description}</p>
                      </div>

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete event "${ev.title}"?`)) {
                            deleteEvent(ev.id);
                            showSuccess('Event deleted.');
                          }
                        }}
                        className="text-slate-400 hover:text-red-600 p-1.5 rounded hover:bg-red-50"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 5. HERO & STATS */}
          {activeAdminTab === 'hero' && (
            <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
                <Megaphone className="w-4 h-4 text-[#004f28]" />
                Edit Hero Section &amp; Key Institutional Metrics
              </h3>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tagline Badge
                </label>
                <input
                  type="text"
                  value={heroState.taglineBadge}
                  onChange={(e) => setHeroState({ ...heroState, taglineBadge: e.target.value })}
                  className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Headline Prefix
                  </label>
                  <input
                    type="text"
                    value={heroState.titlePrefix}
                    onChange={(e) => setHeroState({ ...heroState, titlePrefix: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Highlighted Word (Underlined)
                  </label>
                  <input
                    type="text"
                    value={heroState.titleHighlight}
                    onChange={(e) => setHeroState({ ...heroState, titleHighlight: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs font-bold text-[#004f28]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Headline Suffix
                  </label>
                  <input
                    type="text"
                    value={heroState.titleSuffix}
                    onChange={(e) => setHeroState({ ...heroState, titleSuffix: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Sub-description Paragraph
                </label>
                <textarea
                  value={heroState.description}
                  onChange={(e) => setHeroState({ ...heroState, description: e.target.value })}
                  rows={2}
                  className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Stat 1 Value</label>
                  <input
                    type="text"
                    value={heroState.stat1Value}
                    onChange={(e) => setHeroState({ ...heroState, stat1Value: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs font-bold text-[#004f28]"
                  />
                  <input
                    type="text"
                    value={heroState.stat1Label}
                    onChange={(e) => setHeroState({ ...heroState, stat1Label: e.target.value })}
                    className="w-full text-[11px] p-1.5 border border-slate-200 rounded-xs mt-1"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Stat 2 Value</label>
                  <input
                    type="text"
                    value={heroState.stat2Value}
                    onChange={(e) => setHeroState({ ...heroState, stat2Value: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs font-bold text-sky-700"
                  />
                  <input
                    type="text"
                    value={heroState.stat2Label}
                    onChange={(e) => setHeroState({ ...heroState, stat2Label: e.target.value })}
                    className="w-full text-[11px] p-1.5 border border-slate-200 rounded-xs mt-1"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Stat 3 Value</label>
                  <input
                    type="text"
                    value={heroState.stat3Value}
                    onChange={(e) => setHeroState({ ...heroState, stat3Value: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs font-bold text-amber-700"
                  />
                  <input
                    type="text"
                    value={heroState.stat3Label}
                    onChange={(e) => setHeroState({ ...heroState, stat3Label: e.target.value })}
                    className="w-full text-[11px] p-1.5 border border-slate-200 rounded-xs mt-1"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Stat 4 Value</label>
                  <input
                    type="text"
                    value={heroState.stat4Value}
                    onChange={(e) => setHeroState({ ...heroState, stat4Value: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs font-bold text-indigo-700"
                  />
                  <input
                    type="text"
                    value={heroState.stat4Label}
                    onChange={(e) => setHeroState({ ...heroState, stat4Label: e.target.value })}
                    className="w-full text-[11px] p-1.5 border border-slate-200 rounded-xs mt-1"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    updateHero(heroState);
                    showSuccess('Hero information updated successfully!');
                  }}
                  className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Hero Section</span>
                </button>
              </div>
            </div>
          )}

          {/* 6. PRINCIPAL'S DESK */}
          {activeAdminTab === 'principal' && (
            <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-[#004f28]" />
                Principal / Superintendent Message &amp; Institutional Vision
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Principal Full Name
                  </label>
                  <input
                    type="text"
                    value={principalState.name}
                    onChange={(e) => setPrincipalState({ ...principalState, name: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Designation
                  </label>
                  <input
                    type="text"
                    value={principalState.designation}
                    onChange={(e) => setPrincipalState({ ...principalState, designation: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Principal Featured Quote
                </label>
                <textarea
                  value={principalState.quote}
                  onChange={(e) => setPrincipalState({ ...principalState, quote: e.target.value })}
                  rows={3}
                  className="w-full text-xs p-2 border border-slate-300 rounded-xs italic"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Sanskrit Sloka
                  </label>
                  <input
                    type="text"
                    value={principalState.slokaHindi}
                    onChange={(e) => setPrincipalState({ ...principalState, slokaHindi: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs text-amber-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Sloka Meaning (English)
                  </label>
                  <input
                    type="text"
                    value={principalState.slokaEnglish}
                    onChange={(e) => setPrincipalState({ ...principalState, slokaEnglish: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Presidential Message
                </label>
                <textarea
                  value={principalState.fullMessage}
                  onChange={(e) => setPrincipalState({ ...principalState, fullMessage: e.target.value })}
                  rows={4}
                  className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                />
              </div>

              <button
                type="button"
                onClick={() => {
                  updatePrincipalDesk(principalState);
                  showSuccess("Principal's Desk updated successfully!");
                }}
                className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Message</span>
              </button>
            </div>
          )}

          {/* 7. INSTITUTION INFO & CONTACT */}
          {activeAdminTab === 'institution' && (
            <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
                <Building className="w-4 h-4 text-[#004f28]" />
                Institutional Directory &amp; Contact Details
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    State Government
                  </label>
                  <input
                    type="text"
                    value={instState.state}
                    onChange={(e) => setInstState({ ...instState, state: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Parent Directorate
                  </label>
                  <input
                    type="text"
                    value={instState.department}
                    onChange={(e) => setInstState({ ...instState, department: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Institute Name
                </label>
                <input
                  type="text"
                  value={instState.instituteName}
                  onChange={(e) => setInstState({ ...instState, instituteName: e.target.value })}
                  className="w-full text-xs p-2 border border-slate-300 rounded-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Sub-location &amp; Street Address
                </label>
                <input
                  type="text"
                  value={instState.subLocation}
                  onChange={(e) => setInstState({ ...instState, subLocation: e.target.value })}
                  className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Official Helpline Telephone
                  </label>
                  <input
                    type="text"
                    value={instState.helpline}
                    onChange={(e) => setInstState({ ...instState, helpline: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Official Public Email
                  </label>
                  <input
                    type="email"
                    value={instState.email}
                    onChange={(e) => setInstState({ ...instState, email: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    NCVT MIS Code
                  </label>
                  <input
                    type="text"
                    value={instState.ncvtMisCode}
                    onChange={(e) => setInstState({ ...instState, ncvtMisCode: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Established Year
                  </label>
                  <input
                    type="text"
                    value={instState.estdYear}
                    onChange={(e) => setInstState({ ...instState, estdYear: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Office Hours
                  </label>
                  <input
                    type="text"
                    value={instState.workingHours}
                    onChange={(e) => setInstState({ ...instState, workingHours: e.target.value })}
                    className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  updateInstitution(instState);
                  showSuccess('Institute information updated!');
                }}
                className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Institutional Details</span>
              </button>
            </div>
          )}

          {/* 8. MARQUEE ALERTS */}
          {activeAdminTab === 'alerts' && (
            <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
                <Megaphone className="w-4 h-4 text-amber-600" />
                Manage Live Bulletin Ticker &amp; Rolling Alerts
              </h3>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Add New Urgent Rolling Alert
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newTickerText}
                    onChange={(e) => setNewTickerText(e.target.value)}
                    placeholder="e.g. Supplementary CBT Exam forms available at Trainee Counter till 15th June."
                    className="flex-1 text-xs p-2 border border-slate-300 rounded-xs"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!newTickerText.trim()) return;
                      const updated = [newTickerText, ...alertsState];
                      setAlertsState(updated);
                      updateTickerAlerts(updated);
                      setNewTickerText('');
                      showSuccess('New marquee alert pushed!');
                    }}
                    className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold px-4 rounded-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add
                  </button>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <label className="block text-xs font-semibold text-slate-700">
                  Active Rolling Notices ({alertsState.length}):
                </label>
                {alertsState.map((alert, idx) => (
                  <div key={idx} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xs flex items-center justify-between gap-3 text-xs">
                    <span className="text-slate-800 flex-1">{alert}</span>
                    <button
                      onClick={() => {
                        const updated = alertsState.filter((_, i) => i !== idx);
                        setAlertsState(updated);
                        updateTickerAlerts(updated);
                        showSuccess('Alert removed.');
                      }}
                      className="text-slate-400 hover:text-red-600 p-1 rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 9. TENDERS & E-PROCUREMENT */}
          {activeAdminTab === 'tenders' && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h3 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-[#004f28]" />
                  Upload New E-Tender Notice
                </h3>

                <form onSubmit={handleAddTender} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Tender Title &amp; Scope of Work *
                    </label>
                    <input
                      type="text"
                      value={newTenderTitle}
                      onChange={(e) => setNewTenderTitle(e.target.value)}
                      placeholder="e.g. Procurement & Installation of CNC Lathe Tooling Sets"
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Tender Reference ID
                      </label>
                      <input
                        type="text"
                        value={newTenderId}
                        onChange={(e) => setNewTenderId(e.target.value)}
                        placeholder="2026_DSD_99480"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Publish Date
                      </label>
                      <input
                        type="text"
                        value={newTenderPublished}
                        onChange={(e) => setNewTenderPublished(e.target.value)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Bid Submission Deadline
                      </label>
                      <input
                        type="text"
                        value={newTenderClosing}
                        onChange={(e) => setNewTenderClosing(e.target.value)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Estimated Project Value
                      </label>
                      <input
                        type="text"
                        value={newTenderValue}
                        onChange={(e) => setNewTenderValue(e.target.value)}
                        placeholder="₹ 15,00,000/-"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Tender Document File Size
                      </label>
                      <input
                        type="text"
                        value={newTenderDocSize}
                        onChange={(e) => setNewTenderDocSize(e.target.value)}
                        placeholder="PDF (2.4 MB)"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Publish E-Tender Notice</span>
                  </button>
                </form>
              </div>

              {/* Tenders List */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-3">
                  Active E-Tenders &amp; Procurements ({tenders.length})
                </h4>
                <div className="divide-y divide-slate-100">
                  {tenders.map((t) => (
                    <div key={t.id} className="py-3 flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] font-mono font-bold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded-xs">
                            ID: {t.tenderId}
                          </span>
                          <span className="text-[11px] text-slate-500">Closing: {t.closingDate}</span>
                          <span className="text-[11px] font-semibold text-[#004f28]">Est: {t.estimatedValue}</span>
                        </div>
                        <p className="text-xs font-bold text-slate-900">{t.title}</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">{t.tenderDocSize}</p>
                      </div>

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete tender "${t.title}"?`)) {
                            deleteTender(t.id);
                            showSuccess('Tender deleted.');
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 10. FACILITIES & WORKSHOPS */}
          {activeAdminTab === 'facilities' && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h3 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#004f28]" />
                  Add Campus Facility / Workshop Bay
                </h3>

                <form onSubmit={handleAddFacility} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Facility Name *
                      </label>
                      <input
                        type="text"
                        value={newFacName}
                        onChange={(e) => setNewFacName(e.target.value)}
                        placeholder="e.g. Drone Piloting & Electronics Lab"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Category
                      </label>
                      <select
                        value={newFacCat}
                        onChange={(e) => setNewFacCat(e.target.value as any)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      >
                        <option value="Workshops">Workshops</option>
                        <option value="Smart Labs">Smart Labs</option>
                        <option value="Hostel & Amenities">Hostel &amp; Amenities</option>
                        <option value="Renewable Energy">Renewable Energy</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Intake Capacity / Seats
                      </label>
                      <input
                        type="text"
                        value={newFacCapacity}
                        onChange={(e) => setNewFacCapacity(e.target.value)}
                        placeholder="24 Trainees per Shift"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Machinery &amp; Equipment Available
                      </label>
                      <input
                        type="text"
                        value={newFacMachinery}
                        onChange={(e) => setNewFacMachinery(e.target.value)}
                        placeholder="CNC machines, digital verniers, soldering stations..."
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Brief Description
                    </label>
                    <textarea
                      value={newFacDesc}
                      onChange={(e) => setNewFacDesc(e.target.value)}
                      placeholder="Practical industrial curriculum details..."
                      rows={2}
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Register Facility</span>
                  </button>
                </form>
              </div>

              {/* Facilities List */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-3">
                  Registered Institute Facilities ({facilities.length})
                </h4>
                <div className="divide-y divide-slate-100">
                  {facilities.map((fac) => (
                    <div key={fac.id} className="py-2.5 flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">{fac.name}</span>
                          <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded-xs font-semibold">
                            {fac.category}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#004f28] font-semibold mt-0.5">
                          Capacity: {fac.capacity} · Equipment: {fac.machinery}
                        </p>
                        <p className="text-[11px] text-slate-500">{fac.description}</p>
                      </div>

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete facility "${fac.name}"?`)) {
                            deleteFacility(fac.id);
                            showSuccess('Facility removed.');
                          }
                        }}
                        className="text-slate-400 hover:text-red-600 p-1.5 rounded"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 11. RTI & MANDATORY DISCLOSURES */}
          {activeAdminTab === 'disclosures' && (
            <div className="space-y-6">
              {/* Add Disclosure */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h3 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
                  <Scale className="w-4 h-4 text-[#004f28]" />
                  Upload Mandatory Compliance Disclosure / NOC
                </h3>

                <form onSubmit={handleAddDisclosure} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Disclosure Document Title *
                    </label>
                    <input
                      type="text"
                      value={newDiscTitle}
                      onChange={(e) => setNewDiscTitle(e.target.value)}
                      placeholder="e.g. Building Safety Certificate by PWD Executive Engineer"
                      className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Category
                      </label>
                      <select
                        value={newDiscCat}
                        onChange={(e) => setNewDiscCat(e.target.value as any)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      >
                        <option value="Affiliation Order">Affiliation Order</option>
                        <option value="Building Safety">Building Safety</option>
                        <option value="Fire NOC">Fire NOC</option>
                        <option value="Staff Structure">Staff Structure</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Order / Dispatch Number
                      </label>
                      <input
                        type="text"
                        value={newDiscDocNo}
                        onChange={(e) => setNewDiscDocNo(e.target.value)}
                        placeholder="DSD/Est/2026/89"
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Approval Date
                      </label>
                      <input
                        type="text"
                        value={newDiscDate}
                        onChange={(e) => setNewDiscDate(e.target.value)}
                        className="w-full text-xs p-2 border border-slate-300 rounded-xs"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="bg-[#004f28] hover:bg-[#046a38] text-white text-xs font-semibold py-2 px-4 rounded-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Upload Disclosure</span>
                  </button>
                </form>
              </div>

              {/* RTI Officers Editor */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-3">
                  RTI Act 2005 Designated Officers
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {rtiOfficers.map((officer, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-xs space-y-2 text-xs">
                      <span className="font-bold text-[#004f28]">{officer.designation}</span>
                      <div>
                        <label className="text-[10px] text-slate-500 block">Officer Name:</label>
                        <input
                          type="text"
                          value={officer.name}
                          onChange={(e) => updateRtiOfficer(idx, { name: e.target.value })}
                          className="w-full p-1.5 text-xs border border-slate-300 rounded-xs bg-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 block">Phone / Contact:</label>
                        <input
                          type="text"
                          value={officer.phone}
                          onChange={(e) => updateRtiOfficer(idx, { phone: e.target.value })}
                          className="w-full p-1.5 text-xs border border-slate-300 rounded-xs bg-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 block">Official Email:</label>
                        <input
                          type="text"
                          value={officer.email}
                          onChange={(e) => updateRtiOfficer(idx, { email: e.target.value })}
                          className="w-full p-1.5 text-xs border border-slate-300 rounded-xs bg-white"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Existing Disclosures */}
              <div className="bg-white p-5 rounded-xs border border-slate-200 shadow-xs">
                <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-3">
                  Published Mandatory Compliance Disclosures ({mandatoryDisclosures.length})
                </h4>
                <div className="divide-y divide-slate-100">
                  {mandatoryDisclosures.map((d) => (
                    <div key={d.id} className="py-2.5 flex items-center justify-between gap-4">
                      <div>
                        <p className="text-xs font-bold text-slate-900">{d.title}</p>
                        <p className="text-[11px] text-slate-500">
                          {d.category} · Ref: {d.docNumber} · {d.fileSize}
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete disclosure "${d.title}"?`)) {
                            deleteMandatoryDisclosure(d.id);
                            showSuccess('Disclosure deleted.');
                          }
                        }}
                        className="text-slate-400 hover:text-red-600 p-1.5 rounded"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 12. DATA ENTRY GUIDE & DIRECTORY */}
          {activeAdminTab === 'guide' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-[#004f28] to-[#046a38] text-white p-5 rounded-xs shadow-xs">
                <h3 className="font-bold text-base flex items-center gap-2">
                  <HelpCircle className="w-5 h-5 text-amber-300" />
                  Administrator Data Entry &amp; Function Directory
                </h3>
                <p className="text-xs text-white/90 mt-1">
                  Here is where every function and button on the Govt ITI Udhampur portal receives its data. Click any shortcut to jump directly to its upload/edit form!
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {[
                  {
                    title: '1. Orders & Circulars (Downloads)',
                    desc: 'Counseling merit lists, CBT examination guidelines, seat allocations, official orders.',
                    button: 'Upload / Edit Orders',
                    tab: 'orders',
                    badge: 'Downloads & Notice Board'
                  },
                  {
                    title: '2. Institute Tenders (E-Procurement)',
                    desc: 'Procurement tenders for CNC tools, raw material contracts, laboratory equipment bids.',
                    button: 'Manage E-Tenders',
                    tab: 'tenders',
                    badge: 'Citizen Hub: Tenders'
                  },
                  {
                    title: '3. Campus Photos & Media Gallery',
                    desc: 'Campus hero banner image, workshop photography, Principal portrait, smart lab albums.',
                    button: 'Update Photos & Gallery',
                    tab: 'photos',
                    badge: 'Hero & Photo Gallery'
                  },
                  {
                    title: '4. Trades & Vocational Courses',
                    desc: 'CTS courses across IT, Engineering, and Consumer Sectors; course duration, eligibility, seats.',
                    button: 'Add / Edit Trades',
                    tab: 'trades',
                    badge: 'Vocational Matrix'
                  },
                  {
                    title: '5. Upcoming Events & Calendar',
                    desc: 'Apprenticeship Melas, Tech Fests, Solar workshops, safety drills, CBT date sheets.',
                    button: 'Schedule Events',
                    tab: 'events',
                    badge: 'Calendar & News'
                  },
                  {
                    title: '6. Workshops & Campus Facilities',
                    desc: 'CNC Machining center, EV diagnostic bays, Smart COPA labs, renewable energy rigs.',
                    button: 'Manage Facilities',
                    tab: 'facilities',
                    badge: 'About Us & Facilities'
                  },
                  {
                    title: '7. RTI Act 2005 & Disclosures',
                    desc: 'Designated Public Information Officers (PIO), DGT affiliation orders, PWD safety NOCs.',
                    button: 'Edit RTI & Compliance',
                    tab: 'disclosures',
                    badge: 'Citizen Hub: RTI'
                  },
                  {
                    title: '8. Live Marquee Announcements',
                    desc: 'Top rolling ticker announcements under the main green navigation bar.',
                    button: 'Manage Marquee Alerts',
                    tab: 'alerts',
                    badge: 'Top Banner Ticker'
                  },
                  {
                    title: "9. Principal's Desk Message",
                    desc: "Superintendent Er. Ravinder Singh Bhatti's address, quote, and Sanskrit sloka.",
                    button: "Edit Principal's Message",
                    tab: 'principal',
                    badge: "Principal's Desk"
                  },
                  {
                    title: '10. Institutional Info & Contacts',
                    desc: 'Helpline (+91 1992 270428), email, campus address, NCVT MIS code (GU01000011).',
                    button: 'Edit Institute Details',
                    tab: 'institution',
                    badge: 'Header, Footer & Contact'
                  }
                ].map((item, idx) => (
                  <div key={idx} className="bg-white p-4 rounded-xs border border-slate-200 shadow-xs flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-xs font-bold text-slate-900">{item.title}</h4>
                        <span className="text-[10px] font-semibold bg-emerald-50 text-[#004f28] px-1.5 py-0.5 rounded-xs">
                          {item.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 leading-relaxed mt-1">{item.desc}</p>
                    </div>

                    <div className="pt-3 mt-2 border-t border-slate-100">
                      <button
                        onClick={() => openAdminTab(item.tab)}
                        className="w-full bg-[#004f28] hover:bg-[#046a38] text-white py-1.5 px-3 rounded-xs font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <span>{item.button}</span>
                        <Upload className="w-3 h-3 text-emerald-300" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="bg-slate-100 border-t border-slate-200 p-3 px-6 flex items-center justify-between text-xs text-slate-500">
          <span>Admin changes are auto-saved to persistent local storage.</span>
          <button
            onClick={() => setIsEditDrawerOpen(false)}
            className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-1.5 rounded-xs font-medium cursor-pointer"
          >
            Close Panel
          </button>
        </div>

      </div>
    </div>
  );
};
