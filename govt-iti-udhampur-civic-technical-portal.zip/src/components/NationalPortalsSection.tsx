import React from 'react';
import { usePortal } from '../context/PortalContext';
import { ExternalLink } from 'lucide-react';

export const NationalPortalsSection: React.FC = () => {
  const { nationalPortals } = usePortal();

  return (
    <section className="py-6 bg-[#f8fafc] border-b border-slate-200">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 mb-3 border-b border-slate-200 gap-2">
          <h3 className="text-xs sm:text-sm font-bold text-slate-800 uppercase tracking-wider">
            Important National Portals &amp; Affiliations
          </h3>
          <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
            Direct Access
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          {nationalPortals.map((portal) => (
            <a
              key={portal.id}
              href={portal.url}
              target="_blank"
              rel="noreferrer"
              className="bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-400 p-2.5 rounded-xs text-center transition-all group flex flex-col items-center justify-center shadow-xs"
            >
              <span className="text-xs font-bold text-slate-900 group-hover:text-[#004f28] leading-tight">
                {portal.name}
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">
                {portal.subText}
              </span>
            </a>
          ))}
        </div>

      </div>
    </section>
  );
};
