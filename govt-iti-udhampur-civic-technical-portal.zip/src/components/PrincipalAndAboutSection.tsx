import React from 'react';
import { usePortal } from '../context/PortalContext';
import {
  ShieldCheck,
  Users,
  Award,
  Wallet,
  Building,
  FileCheck,
  ArrowRight,
  Edit2
} from 'lucide-react';

export const PrincipalAndAboutSection: React.FC = () => {
  const { principalDesk, isAdmin, openAdminTab, openModal } = usePortal();

  return (
    <section id="about" className="py-10 bg-[#faf8ff] border-b border-slate-200">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Column: Principal's Desk (5 cols) */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xs p-6 shadow-xs flex flex-col justify-between">
            <div>
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-5 bg-[#004f28] rounded-xs"></div>
                  <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                    Principal's Desk
                  </h2>
                </div>
                {isAdmin && (
                  <button
                    onClick={() => openAdminTab('principal')}
                    className="text-xs text-slate-500 hover:text-[#004f28] flex items-center gap-1 cursor-pointer"
                    title="Edit Principal message"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>
                )}
              </div>

              {/* Principal Profile Box */}
              <div className="flex items-center gap-4 my-4">
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xs overflow-hidden border border-slate-300 bg-slate-100 shrink-0 shadow-xs">
                  <img
                    src={principalDesk.photoUrl}
                    alt={principalDesk.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-tight">
                    {principalDesk.name}
                  </h3>
                  <p className="text-xs font-semibold text-[#004f28] mt-0.5">
                    {principalDesk.designation}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    {principalDesk.institute}
                  </p>
                </div>
              </div>

              {/* Principal Message / Quote */}
              <div className="space-y-3 text-xs sm:text-[13px] text-slate-700 leading-relaxed">
                <p className="italic">
                  {principalDesk.quote}
                </p>

                <p className="text-slate-600">
                  Our mission at ITI Udhampur is to bridge academic theories with rigorous workshop practice. We transform enthusiastic rural and urban learners into precision craftsmen ready for the world’s most demanding industries.
                </p>

                {/* Sanskrit Sloka Box */}
                <div className="bg-[#eaedff] border-l-3 border-[#06038d] p-3 rounded-xs text-xs space-y-1">
                  <p className="font-bold text-[#06038d] font-serif">
                    {principalDesk.slokaHindi}
                  </p>
                  <p className="text-[11px] text-slate-600 italic">
                    {principalDesk.slokaEnglish}
                  </p>
                </div>
              </div>
            </div>

            {/* Read Full Message Button */}
            <div className="pt-4 mt-4 border-t border-slate-100">
              <button
                onClick={() => openModal('principal-speech')}
                className="w-full bg-[#004f28] hover:bg-[#046a38] text-white py-2.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>READ FULL MESSAGE</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right Column: About Govt ITI Udhampur (7 cols) */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xs p-6 shadow-xs flex flex-col justify-between">
            <div>
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-5 bg-[#06038d] rounded-xs"></div>
                  <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                    About Govt ITI Udhampur
                  </h2>
                </div>
              </div>

              {/* Institution Overview Text */}
              <div className="text-xs sm:text-[13px] text-slate-700 leading-relaxed space-y-2 mt-4 mb-5">
                <p>
                  Government Industrial Training Institute (ITI) Udhampur is a premier technical training institution operating under the aegis of the Directorate of Skill Development, Government of Jammu &amp; Kashmir. Established in 1976 and centrally situated on Dhar Road near Subhash Stadium, the institute has spent nearly five decades unlocking livelihood opportunities for thousands of young men and women.
                </p>
                <p className="text-slate-600">
                  We deliver National Council for Vocational Training (NCVT) and State Council for Vocational Training (SCVT) standardized curricula across 18 distinct engineering and non-engineering trades. The institute operates dedicated CNC tooling setups, high-precision lathe labs, computer software facilities, and green-energy testing modules.
                </p>
              </div>

              {/* 4 Feature Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                
                {/* 1. DGT & NCVT */}
                <div className="bg-[#f2f3ff] border border-slate-200 p-3 rounded-xs flex items-start gap-2.5">
                  <div className="p-1.5 bg-emerald-100 text-[#004f28] rounded-xs shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      DGT &amp; NCVT Accredited
                    </h3>
                    <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                      Uniform nationwide syllabus and international skill recognition.
                    </p>
                  </div>
                </div>

                {/* 2. Dual System of Training */}
                <div className="bg-[#f2f3ff] border border-slate-200 p-3 rounded-xs flex items-start gap-2.5">
                  <div className="p-1.5 bg-blue-100 text-[#06038d] rounded-xs shrink-0">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      Dual System of Training
                    </h3>
                    <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                      Joint industrial internship partnerships with MSMEs and PSUs.
                    </p>
                  </div>
                </div>

                {/* 3. Dedicated Women's Wing */}
                <div className="bg-[#f2f3ff] border border-slate-200 p-3 rounded-xs flex items-start gap-2.5">
                  <div className="p-1.5 bg-amber-100 text-[#a73a00] rounded-xs shrink-0">
                    <Award className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      Dedicated Women's Wing
                    </h3>
                    <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                      Specialized intake in COPA, Dress Making, and ICT trades.
                    </p>
                  </div>
                </div>

                {/* 4. Post-Matric Aid */}
                <div className="bg-[#f2f3ff] border border-slate-200 p-3 rounded-xs flex items-start gap-2.5">
                  <div className="p-1.5 bg-emerald-100 text-[#004f28] rounded-xs shrink-0">
                    <Wallet className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      Post-Matric Aid
                    </h3>
                    <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                      Direct benefit transfer stipends and merit fee waivers.
                    </p>
                  </div>
                </div>

              </div>
            </div>

            {/* Bottom 2 Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-100">
              <button
                onClick={() => openModal('campus-facilities')}
                className="bg-[#fd661d] hover:bg-[#a73a00] text-white py-2.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
              >
                <span>INSTITUTE HISTORY &amp; FACILITIES</span>
                <Building className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => openModal('mandatory-disclosures')}
                className="bg-[#e2e7ff] hover:bg-[#d0d1ff] text-[#06038d] py-2.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>MANDATORY DISCLOSURES</span>
                <FileCheck className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
