import React from 'react';
import { usePortal } from '../context/PortalContext';
import { Phone, Mail, MapPin, ExternalLink, ShieldCheck } from 'lucide-react';

export const FooterSection: React.FC = () => {
  const { institution, openModal } = usePortal();

  // Format visitor count with padded zeros like 00482914
  const formattedCounter = String(institution.visitorCount).padStart(8, '0');

  return (
    <footer className="bg-[#f8fafc] text-slate-700 border-t-2 border-[#004f28] text-xs">
      
      {/* 4 Columns Top Grid */}
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Col 1: Govt ITI Udhampur */}
          <div className="space-y-3">
            <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-tight">
              Govt ITI Udhampur
            </h3>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              Empowering regional youth with industry-aligned technical craftsmanship under the Directorate of Skill Development, Govt of Jammu &amp; Kashmir.
            </p>
            <div className="text-[11px] text-slate-800 font-semibold pt-1">
              <p>{institution.address}</p>
            </div>
          </div>

          {/* Col 2: Apex Portals */}
          <div className="space-y-3">
            <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-tight">
              Apex Portals
            </h3>
            <ul className="space-y-1.5 text-[11px]">
              <li>
                <a href="https://ncvtmis.gov.in" target="_blank" rel="noreferrer" className="hover:text-[#004f28] hover:underline flex items-center gap-1">
                  <span>NCVT MIS Portal</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
              <li>
                <a href="https://dgt.gov.in" target="_blank" rel="noreferrer" className="hover:text-[#004f28] hover:underline flex items-center gap-1">
                  <span>DGT, Ministry of Skill Development</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
              <li>
                <a href="https://skillindiadigital.gov.in" target="_blank" rel="noreferrer" className="hover:text-[#004f28] hover:underline flex items-center gap-1">
                  <span>Skill India Digital</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
              <li>
                <a href="https://jkdsd.in" target="_blank" rel="noreferrer" className="hover:text-[#004f28] hover:underline flex items-center gap-1">
                  <span>Directorate of Skill Development J&amp;K</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
              <li>
                <a href="https://digitalindia.gov.in" target="_blank" rel="noreferrer" className="hover:text-[#004f28] hover:underline flex items-center gap-1">
                  <span>Digital India Initiative</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Navigation */}
          <div className="space-y-3">
            <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-tight">
              Quick Navigation
            </h3>
            <ul className="space-y-1.5 text-[11px]">
              <li>
                <a href="#trades" className="hover:text-[#004f28] hover:underline">
                  Engineering Trades Matrix
                </a>
              </li>
              <li>
                <button onClick={() => openModal('download-prospectus')} className="hover:text-[#004f28] hover:underline text-left cursor-pointer">
                  CTS Admission Prospectus
                </button>
              </li>
              <li>
                <button onClick={() => openModal('academic-calendar')} className="hover:text-[#004f28] hover:underline text-left cursor-pointer">
                  NCVT Examination Schedules
                </button>
              </li>
              <li>
                <button onClick={() => openModal('tenders')} className="hover:text-[#004f28] hover:underline text-left cursor-pointer">
                  RTI &amp; Active Tenders
                </button>
              </li>
              <li>
                <button onClick={() => openModal('grievance')} className="hover:text-[#004f28] hover:underline text-left cursor-pointer">
                  Grievance Redressal
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Official Records & Stats */}
          <div className="space-y-3">
            <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-tight">
              Official Records
            </h3>

            {/* Visitor Counter Box */}
            <div className="bg-slate-200/80 border border-slate-300 p-2.5 rounded-xs space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-semibold text-slate-700">Visitor Counter:</span>
                <span className="font-mono font-bold text-slate-900 bg-white px-1.5 py-0.5 rounded border border-slate-300 tracking-wider">
                  {formattedCounter}
                </span>
              </div>
              <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-300/60">
                Last Updated: <strong className="text-slate-700">{institution.lastUpdated}</strong>
              </div>
              <div className="text-[10px] text-slate-500">
                NCVT Code: <strong className="font-mono text-slate-700">{institution.ncvtCode}</strong>
              </div>
            </div>

            <div className="text-[11px] text-slate-700 space-y-1">
              <p>
                Direct Telephone: <strong className="text-slate-900">{institution.helpline}</strong>
              </p>
              <p>
                Email: <strong className="text-slate-900">{institution.email}</strong>
              </p>
            </div>
          </div>

        </div>
      </div>

      {/* Bottom Legal Copyright Strip */}
      <div className="bg-slate-200/60 border-t border-slate-300 py-3.5 px-4 sm:px-6 text-[11px] text-slate-600">
        <div className="max-w-[1240px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <p>
            © 2026 Govt ITI Udhampur. All Rights Reserved. Maintained by IT Cell, ITI Udhampur.
          </p>

          <div className="flex items-center space-x-3 text-slate-600 font-medium">
            <a href="#terms" onClick={(e) => { e.preventDefault(); openModal('legal-terms'); }} className="hover:text-slate-900 hover:underline">
              Terms of Use
            </a>
            <span>•</span>
            <a href="#privacy" onClick={(e) => { e.preventDefault(); openModal('legal-privacy'); }} className="hover:text-slate-900 hover:underline">
              Privacy Policy
            </a>
            <span>•</span>
            <a href="#hyperlink" onClick={(e) => { e.preventDefault(); openModal('legal-hyperlink'); }} className="hover:text-slate-900 hover:underline">
              Hyperlinking Policy
            </a>
            <span>•</span>
            <a href="#accessibility" onClick={(e) => { e.preventDefault(); openModal('legal-accessibility'); }} className="hover:text-slate-900 hover:underline">
              Accessibility Statement
            </a>
          </div>
        </div>
      </div>

    </footer>
  );
};
