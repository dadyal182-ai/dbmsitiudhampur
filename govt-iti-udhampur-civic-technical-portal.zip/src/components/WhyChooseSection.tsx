import React from 'react';
import { usePortal } from '../context/PortalContext';
import {
  Download,
  Wrench,
  ShieldCheck,
  GraduationCap,
  Building2,
  Wallet,
  Trees
} from 'lucide-react';

export const WhyChooseSection: React.FC = () => {
  const { openModal } = usePortal();

  const iconMap: Record<string, React.ReactNode> = {
    '100% Practical Training': <Wrench className="w-5 h-5 text-emerald-700" />,
    'Govt Recognized': <ShieldCheck className="w-5 h-5 text-blue-700" />,
    'Certified Faculty': <GraduationCap className="w-5 h-5 text-purple-700" />,
    'Industry Placements': <Building2 className="w-5 h-5 text-teal-700" />,
    'Scholarship Support': <Wallet className="w-5 h-5 text-[#a73a00]" />,
    'Campus Environment': <Trees className="w-5 h-5 text-emerald-600" />
  };

  const bgMap: Record<string, string> = {
    '100% Practical Training': 'bg-emerald-50',
    'Govt Recognized': 'bg-blue-50',
    'Certified Faculty': 'bg-purple-50',
    'Industry Placements': 'bg-teal-50',
    'Scholarship Support': 'bg-amber-50',
    'Campus Environment': 'bg-emerald-50'
  };

  const points = [
    {
      title: '100% Practical Training',
      description: 'Full-scale industrial workshops equipped with live CNC machines, lathe beds, and automotive overhaul simulators.'
    },
    {
      title: 'Govt Recognized',
      description: 'NCVT & SCVT certificates recognized by Central PSUs, Railways, Defense, and international employer councils.'
    },
    {
      title: 'Certified Faculty',
      description: 'Craft Instructor Training Scheme (CITS) certified instructors with over 15+ years of practical sector expertise.'
    },
    {
      title: 'Industry Placements',
      description: 'Dedicated training and placement cell organizing regular campus interviews with Maruti Suzuki, Tata, and NHPC.'
    },
    {
      title: 'Scholarship Support',
      description: 'Post-Matric, PMSSS, and Pragati scholarships with direct benefit transfer credit straight to trainee bank accounts.'
    },
    {
      title: 'Campus Environment',
      description: 'Peaceful green setting along Dhar Road, near Subhash Stadium with smart classrooms, digital library, and sports facility.'
    }
  ];

  return (
    <section className="py-10 bg-[#faf8ff] border-b border-slate-200">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Left Saffron Callout Box (4 cols) */}
          <div className="lg:col-span-4 bg-[#fd661d] text-white p-6 sm:p-8 rounded-xs shadow-md flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#370e00] bg-white/30 px-2 py-0.5 rounded-xs inline-block">
                INSTITUTIONAL CALIBER
              </span>

              <h2 className="text-2xl sm:text-3xl font-black leading-tight text-white tracking-tight">
                Why Choose Govt ITI Udhampur?
              </h2>

              <p className="text-xs sm:text-sm text-white/95 leading-relaxed">
                A proven pathway from regional schooling to assured industrial employability. We combine rigorous workshop ethics, state-subsidized fees, and pan-India certified credentials.
              </p>
            </div>

            <div className="pt-6">
              <button
                onClick={() => openModal('download-prospectus')}
                className="w-full bg-white hover:bg-slate-100 text-[#a73a00] font-bold text-xs uppercase tracking-wider py-3 px-4 rounded-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm"
              >
                <span>DOWNLOAD ADMISSION PROSPECTUS</span>
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right 6 Cards Grid (8 cols) */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {points.map((pt) => (
              <div
                key={pt.title}
                className="bg-white border border-slate-200 p-4 rounded-xs shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className={`w-9 h-9 rounded-xs flex items-center justify-center mb-3 ${bgMap[pt.title] || 'bg-slate-100'}`}>
                    {iconMap[pt.title] || <Wrench className="w-5 h-5 text-slate-700" />}
                  </div>

                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug mb-1.5">
                    {pt.title}
                  </h3>

                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {pt.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
};
