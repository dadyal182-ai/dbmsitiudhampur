import React from 'react';
import { usePortal } from '../context/PortalContext';
import { MapPin, Phone, Mail, Navigation, ExternalLink, Clock } from 'lucide-react';

export const CampusAccessibilitySection: React.FC = () => {
  const { institution } = usePortal();

  return (
    <section id="contact" className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Column (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#004f28] bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-xs inline-block mb-1.5">
                CAMPUS ACCESSIBILITY
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Visit Government ITI Udhampur
              </h2>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Situated on Dhar Road adjacent to District Hospital Udhampur, our campus is seamlessly connected to Udhampur Railway Station (4.2 km) and the central bus terminal (1.5 km), ensuring convenient daily commute for students across the Udhampur and Chenani valleys.
            </p>

            {/* Contact Details List */}
            <div className="space-y-3 pt-2 text-xs">
              
              <div className="flex items-start gap-3 bg-[#faf8ff] p-3 rounded-xs border border-slate-200">
                <div className="p-1.5 bg-[#004f28]/10 text-[#004f28] rounded-xs shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">Official Campus Address</h3>
                  <p className="text-slate-600 mt-0.5">{institution.address}</p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-[#faf8ff] p-3 rounded-xs border border-slate-200">
                <div className="p-1.5 bg-[#004f28]/10 text-[#004f28] rounded-xs shrink-0 mt-0.5">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">Institute Telephone</h3>
                  <p className="text-slate-600 mt-0.5">
                    {institution.helpline} <span className="text-slate-400">({institution.workingHours})</span>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-[#faf8ff] p-3 rounded-xs border border-slate-200">
                <div className="p-1.5 bg-[#004f28]/10 text-[#004f28] rounded-xs shrink-0 mt-0.5">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">Official E-Mail</h3>
                  <p className="text-slate-600 mt-0.5">{institution.email}</p>
                </div>
              </div>

            </div>

            <div className="pt-2">
              <a
                href="https://www.google.com/maps/search/Govt+ITI+Udhampur+Dhar+Road"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 bg-[#004f28] hover:bg-[#046a38] text-white px-4 py-2 rounded-xs font-bold text-xs uppercase tracking-wider transition-colors shadow-xs"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Get Driving Directions</span>
              </a>
            </div>

          </div>

          {/* Right Column (Styled Map Visual) - 7 cols */}
          <div className="lg:col-span-7">
            <div className="relative rounded-sm border border-slate-300 overflow-hidden shadow-md bg-[#e5e3df] aspect-[16/10]">
              
              {/* Map Canvas Background SVG */}
              <svg viewBox="0 0 600 380" className="w-full h-full object-cover">
                {/* Terrain / Land fill */}
                <rect width="600" height="380" fill="#e8ece9" />

                {/* Greenery / Forest patches */}
                <path d="M 0,0 L 220,0 L 180,90 L 80,120 L 0,80 Z" fill="#d4e8d4" opacity="0.8" />
                <path d="M 380,0 L 600,0 L 600,140 L 480,100 Z" fill="#d6ead6" opacity="0.8" />
                <path d="M 450,220 L 600,200 L 600,380 L 480,380 Z" fill="#cbe4cb" opacity="0.9" />
                <path d="M 0,260 L 140,240 L 160,380 L 0,380 Z" fill="#d6ebd6" opacity="0.8" />

                {/* River / Stream */}
                <path d="M 280,0 Q 290,120 330,190 T 360,380" fill="none" stroke="#aad3df" strokeWidth="8" opacity="0.7" />

                {/* Secondary roads */}
                <path d="M 0,160 L 260,190 L 320,170 L 600,160" fill="none" stroke="#ffffff" strokeWidth="5" strokeLinecap="round" />
                <path d="M 120,0 L 170,220 L 240,380" fill="none" stroke="#ffffff" strokeWidth="4" />
                <path d="M 440,0 L 360,200 L 420,380" fill="none" stroke="#ffffff" strokeWidth="4" />
                <path d="M 210,120 L 480,240" fill="none" stroke="#ffffff" strokeWidth="3" />
                <path d="M 80,310 L 390,300" fill="none" stroke="#ffffff" strokeWidth="3" />

                {/* Primary National Highway 44 (Yellow/Orange double stroke) */}
                <path d="M 260,0 Q 280,140 330,220 T 450,380" fill="none" stroke="#fcd34d" strokeWidth="7" strokeLinecap="round" />
                <path d="M 260,0 Q 280,140 330,220 T 450,380" fill="none" stroke="#f59e0b" strokeWidth="2" strokeDasharray="6 4" />

                {/* Dhar Road branching to ITI */}
                <path d="M 330,220 L 270,260 L 180,250" fill="none" stroke="#fcd34d" strokeWidth="6" strokeLinecap="round" />

                {/* Area Text Labels */}
                <text x="50" y="45" fontSize="11" fill="#475569" fontWeight="600">Sanadi</text>
                <text x="130" y="60" fontSize="11" fill="#475569" fontWeight="600">Harteryan</text>
                <text x="310" y="45" fontSize="11" fill="#475569" fontWeight="600">Mansar</text>
                <text x="460" y="65" fontSize="11" fill="#475569" fontWeight="600">Pakhlai</text>

                <text x="40" y="160" fontSize="11" fill="#475569" fontWeight="600">Chack</text>
                <text x="40" y="174" fontSize="11" fill="#475569" fontWeight="600">Rakwalan</text>

                <text x="140" y="215" fontSize="11" fill="#475569" fontWeight="600">Patla</text>
                <text x="250" y="275" fontSize="11" fill="#475569" fontWeight="600">Tikhri</text>

                <text x="320" y="180" fontSize="10" fill="#64748b" fontWeight="600">OMARA COLONY</text>
                <text x="410" y="175" fontSize="12" fill="#1e293b" fontWeight="bold">Ladan</text>
                <text x="410" y="195" fontSize="11" fill="#475569" fontWeight="bold">BHAGAT NAGAR</text>
                <text x="410" y="220" fontSize="14" fill="#0f172a" fontWeight="800">Udhampur</text>
                <text x="410" y="255" fontSize="11" fill="#475569" fontWeight="600">KOTLI BALA</text>

                <text x="440" y="360" fontSize="11" fill="#475569" fontWeight="600">Baba Peed Mandir</text>
                <text x="530" y="200" fontSize="11" fill="#991b1b" fontWeight="600">Narsingh Mandir Barmeen</text>

                {/* NH-44 Route Shield Badges */}
                <g transform="translate(420, 90)">
                  <rect width="22" height="16" rx="3" fill="#f59e0b" />
                  <text x="11" y="12" fontSize="9" fill="#ffffff" fontWeight="bold" textAnchor="middle">44</text>
                </g>

                <g transform="translate(325, 230)">
                  <rect width="22" height="16" rx="3" fill="#f59e0b" />
                  <text x="11" y="12" fontSize="9" fill="#ffffff" fontWeight="bold" textAnchor="middle">44</text>
                </g>

                <g transform="translate(415, 330)">
                  <rect width="22" height="16" rx="3" fill="#f59e0b" />
                  <text x="11" y="12" fontSize="9" fill="#ffffff" fontWeight="bold" textAnchor="middle">44</text>
                </g>

                {/* Pulsing Pin for ITI Campus */}
                <circle cx="330" cy="220" r="14" fill="#dc2626" opacity="0.25" />
                <circle cx="330" cy="220" r="7" fill="#dc2626" />
                <circle cx="330" cy="220" r="3" fill="#ffffff" />
              </svg>

              {/* Pinpoint Label Card overlay at bottom left */}
              <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-xs border border-slate-300 p-2.5 rounded-xs shadow-lg flex items-center gap-2 max-w-sm">
                <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 leading-tight">
                    Govt ITI Udhampur Campus
                  </h3>
                  <p className="text-[11px] text-slate-600">
                    Dhar Road, Near Subhash Stadium
                  </p>
                </div>
              </div>

              {/* Top right Google Maps link badge */}
              <a
                href="https://www.google.com/maps/search/Govt+ITI+Udhampur"
                target="_blank"
                rel="noreferrer"
                className="absolute top-3 right-3 bg-white/90 hover:bg-white text-slate-800 text-[11px] font-semibold px-2.5 py-1 rounded-xs border border-slate-300 shadow-sm flex items-center gap-1 transition-colors"
              >
                <span>View Live Satellite</span>
                <ExternalLink className="w-3 h-3 text-slate-500" />
              </a>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
