import React, { useState } from 'react';
import { usePortal } from '../context/PortalContext';
import {
  X,
  Download,
  Printer,
  FileText,
  CheckCircle,
  ExternalLink,
  BookOpen,
  Calendar,
  Building,
  ShieldCheck,
  Send,
  Sparkles,
  Info,
  Search,
  PlusCircle,
  Building2,
  Layers,
  Scale,
  FileSpreadsheet,
  Lock,
  AlertCircle,
  Phone,
  Mail,
  MapPin,
  HelpCircle,
  Upload
} from 'lucide-react';
import { TradeItem, OrderCircular } from '../types';

export const Modals: React.FC = () => {
  const {
    activeModal,
    closeModal,
    selectedOrderForModal,
    selectedTradeForModal,
    institution,
    trades,
    gallery,
    principalDesk,
    events,
    orders,
    tenders,
    rtiOfficers,
    facilities,
    mandatoryDisclosures,
    isAdmin,
    openAdminTab,
    openModal
  } = usePortal();

  // State for All Circulars Search & Filter
  const [circularSearch, setCircularSearch] = useState('');
  const [circularCatFilter, setCircularCatFilter] = useState('ALL');

  // State for Admission Application Form
  const [applicantName, setApplicantName] = useState('');
  const [parentName, setParentName] = useState('');
  const [qualification, setQualification] = useState('10th Pass (Matriculation)');
  const [marksPercent, setMarksPercent] = useState('78.4');
  const [selectedTrade, setSelectedTrade] = useState('Electrician (NCVT)');
  const [mobileNo, setMobileNo] = useState('');
  const [appSubmitted, setAppSubmitted] = useState(false);
  const [appRefNo, setAppRefNo] = useState('');

  // State for Grievance
  const [grievanceName, setGrievanceName] = useState('');
  const [grievanceTrade, setGrievanceTrade] = useState('Electrician (NCVT)');
  const [grievanceDesc, setGrievanceDesc] = useState('');
  const [grievanceSubmitted, setGrievanceSubmitted] = useState(false);
  const [grievanceToken, setGrievanceToken] = useState('');

  // State for Gallery Category Filter
  const [galleryFilter, setGalleryFilter] = useState<string>('All');

  if (!activeModal || activeModal === 'admin-login') return null;

  // Handle Admission Submit
  const handleAdmissionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const token = `JK-ITI-UDH-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    setAppRefNo(token);
    setAppSubmitted(true);
  };

  // Handle Grievance Submit
  const handleGrievanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const token = `GRV-UDH-${Math.floor(10000 + Math.random() * 90000)}`;
    setGrievanceToken(token);
    setGrievanceSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      
      {/* 1. ORDER / CIRCULAR VIEW MODAL */}
      {activeModal === 'view-order' && selectedOrderForModal && (
        <div className="bg-white w-full max-w-2xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          {/* Header */}
          <div className="bg-[#004f28] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-emerald-300" />
              <div>
                <h3 className="font-bold text-sm">Official Institutional Order / Circular</h3>
                <p className="text-[11px] text-white/80">Ref: {selectedOrderForModal.refNo}</p>
              </div>
            </div>
            <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Document Simulation Body */}
          <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-800">
            {/* Government Masthead within the Circular */}
            <div className="text-center pb-4 border-b-2 border-slate-300 space-y-0.5">
              <p className="font-bold text-[11px] uppercase tracking-wider text-slate-700">
                GOVERNMENT OF JAMMU &amp; KASHMIR
              </p>
              <p className="font-bold text-xs uppercase text-slate-800">
                DIRECTORATE OF TECHNICAL EDUCATION &amp; SKILL DEVELOPMENT
              </p>
              <h2 className="text-sm font-extrabold text-[#004f28] uppercase">
                GOVERNMENT INDUSTRIAL TRAINING INSTITUTE, UDHAMPUR
              </h2>
              <p className="text-[11px] text-slate-500">
                Dhar Road, Near Subhash Stadium, Udhampur - 182101 (J&amp;K)
              </p>
            </div>

            {/* Reference & Date strip */}
            <div className="flex items-center justify-between font-mono text-xs text-slate-600 pb-2 border-b border-slate-200">
              <span>Order No: <strong>{selectedOrderForModal.refNo}</strong></span>
              <span>Dated: <strong>{selectedOrderForModal.date}</strong></span>
            </div>

            {/* Subject */}
            <div className="bg-slate-50 p-3 rounded-xs border-l-4 border-[#004f28]">
              <span className="font-bold text-slate-900 uppercase text-[11px] block">SUBJECT:</span>
              <p className="font-bold text-slate-900 mt-0.5">{selectedOrderForModal.title}</p>
            </div>

            {/* Content / Directive */}
            <div className="space-y-3 leading-relaxed text-slate-700">
              <p>
                {selectedOrderForModal.description || 
                  'In pursuance to the notification issued by the Directorate of Skill Development, J&K and National Council for Vocational Training (NCVT), notice is hereby promulgated for the information of all concerned candidates and trainees.'}
              </p>
              <p>
                All concerned trainees and applicants are strictly instructed to adhere to the aforementioned timelines. Original academic testimonials, category certificates (where applicable), and requisite passport photographs must be presented for physical document verification at the ITI Administrative Wing.
              </p>
              <p>
                Issued under the authority of: <strong>{selectedOrderForModal.issuingAuthority}</strong>.
              </p>
            </div>

            {/* Signature Block */}
            <div className="pt-6 flex justify-end">
              <div className="text-center font-serif text-xs">
                <div className="italic font-bold text-slate-900 text-sm mb-1">
                  (Er. Ravinder Singh Bhatti)
                </div>
                <p className="font-semibold text-slate-800">Principal / Superintendent</p>
                <p className="text-[11px] text-slate-500">Govt ITI Udhampur (J&amp;K)</p>
              </div>
            </div>
          </div>

          {/* Action Bar */}
          <div className="bg-slate-100 p-3 px-6 border-t border-slate-200 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">
              File Format: {selectedOrderForModal.fileSize}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => window.print()}
                className="bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 px-3 py-1.5 rounded-xs text-xs font-semibold flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" /> Print Circular
              </button>
              <button
                onClick={() => {
                  alert(`Downloading official document: ${selectedOrderForModal.title} (${selectedOrderForModal.fileSize})`);
                }}
                className="bg-[#004f28] hover:bg-[#046a38] text-white px-3.5 py-1.5 rounded-xs text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" /> Download Document
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. APPLY ONLINE ADMISSIONS 2026-27 MODAL */}
      {activeModal === 'apply-online' && (
        <div className="bg-white w-full max-w-xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#a73a00] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-300" />
              <div>
                <h3 className="font-bold text-sm">Online Trainee Admission Form</h3>
                <p className="text-[11px] text-white/80">Academic Session 2026-27 (CTS / NCVT / SCVT)</p>
              </div>
            </div>
            <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 overflow-y-auto">
            {appSubmitted ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-14 h-14 bg-emerald-100 text-[#004f28] rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">Application Submitted Successfully!</h3>
                  <p className="text-xs text-slate-600 mt-1">
                    Your candidate registration has been recorded for Craftsmen Training Scheme (CTS).
                  </p>
                </div>
                <div className="bg-slate-50 border border-slate-200 p-4 rounded-xs inline-block text-left max-w-sm w-full font-mono text-xs">
                  <div className="text-slate-500">Application Registration No:</div>
                  <div className="text-base font-bold text-[#004f28]">{appRefNo}</div>
                  <div className="mt-2 text-slate-700"><strong>Candidate:</strong> {applicantName}</div>
                  <div className="text-slate-700"><strong>Preferred Trade:</strong> {selectedTrade}</div>
                </div>
                <div className="pt-2">
                  <button
                    onClick={() => {
                      setAppSubmitted(false);
                      closeModal();
                    }}
                    className="bg-[#004f28] text-white px-5 py-2 rounded-xs text-xs font-semibold"
                  >
                    Close &amp; Return to Portal
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleAdmissionSubmit} className="space-y-4 text-xs">
                <div className="bg-amber-50 border border-amber-200 p-3 rounded-xs text-amber-900">
                  Admissions for Session 2026-27 are subject to merit in 10th / 8th standard and state reservation guidelines.
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Applicant Full Name *</label>
                    <input
                      type="text"
                      required
                      value={applicantName}
                      onChange={(e) => setApplicantName(e.target.value)}
                      placeholder="e.g. Sunil Sharma"
                      className="w-full p-2 border border-slate-300 rounded-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Father's / Guardian's Name *</label>
                    <input
                      type="text"
                      required
                      value={parentName}
                      onChange={(e) => setParentName(e.target.value)}
                      placeholder="e.g. Sh. Mohan Lal"
                      className="w-full p-2 border border-slate-300 rounded-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Highest Qualification</label>
                    <select
                      value={qualification}
                      onChange={(e) => setQualification(e.target.value)}
                      className="w-full p-2 border border-slate-300 rounded-xs"
                    >
                      <option value="10th Pass (Matriculation)">10th Pass (Matriculation)</option>
                      <option value="12th Pass (Higher Secondary)">12th Pass (Higher Secondary)</option>
                      <option value="8th Pass">8th Pass</option>
                      <option value="Graduate">Graduate</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Matric Marks / Percentage (%) *</label>
                    <input
                      type="text"
                      required
                      value={marksPercent}
                      onChange={(e) => setMarksPercent(e.target.value)}
                      placeholder="78.5"
                      className="w-full p-2 border border-slate-300 rounded-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">First Preference Trade *</label>
                  <select
                    value={selectedTrade}
                    onChange={(e) => setSelectedTrade(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-xs font-semibold text-slate-900"
                  >
                    {trades.map((t) => (
                      <option key={t.id} value={t.name}>
                        {t.name} ({t.duration} - {t.eligibility})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Candidate Mobile Number *</label>
                    <input
                      type="tel"
                      required
                      value={mobileNo}
                      onChange={(e) => setMobileNo(e.target.value)}
                      placeholder="9876543210"
                      className="w-full p-2 border border-slate-300 rounded-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Domicile District</label>
                    <input
                      type="text"
                      defaultValue="Udhampur"
                      className="w-full p-2 border border-slate-300 rounded-xs bg-slate-50"
                      readOnly
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-[#a73a00] hover:bg-[#fd661d] text-white py-2.5 px-4 rounded-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Submit Online Admission Application</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* 3. TRADE SYLLABUS / DETAILS MODAL */}
      {(activeModal === 'view-trade' || activeModal === 'trades-syllabus') && (
        <div className="bg-white w-full max-w-2xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#004f28] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-300" />
              <div>
                <h3 className="font-bold text-sm">
                  {selectedTradeForModal ? selectedTradeForModal.name : 'Craftsmen Training Scheme (CTS) Trades'}
                </h3>
                <p className="text-[11px] text-white/80">Approved by Directorate General of Training (DGT)</p>
              </div>
            </div>
            <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-800">
            {selectedTradeForModal ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-slate-50 p-3 rounded-xs border border-slate-200">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold">Duration</span>
                    <strong className="text-slate-900">{selectedTradeForModal.duration}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold">Eligibility</span>
                    <strong className="text-slate-900">{selectedTradeForModal.eligibility}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold">Affiliation</span>
                    <strong className="text-[#004f28]">{selectedTradeForModal.affiliation}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold">Intake Capacity</span>
                    <strong className="text-slate-900">{selectedTradeForModal.seats || 24} Trainees</strong>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Course Description &amp; Competencies:</h4>
                  <p className="text-slate-600 leading-relaxed text-xs">
                    {selectedTradeForModal.description}
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Core Training Modules:</h4>
                  <ul className="list-disc pl-4 space-y-1 text-xs text-slate-600">
                    <li>Trade Practical (65% Workshop Hours): Hands-on tool handling and equipment testing.</li>
                    <li>Trade Theory (20%): Technical blueprints, mathematical formulas, and materials science.</li>
                    <li>Employability Skills (15%): Communication, English fluency, IT literacy, and environmental safety.</li>
                  </ul>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-slate-600">
                  Select any trade below to review complete syllabus details or download curriculum:
                </p>
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xs">
                  {trades.map((t) => (
                    <div key={t.id} className="p-3 flex items-center justify-between text-xs hover:bg-slate-50">
                      <div>
                        <span className="font-bold text-slate-900">{t.name}</span>
                        <span className="text-[11px] text-slate-500 ml-2">({t.duration} • {t.eligibility})</span>
                      </div>
                      <span className="text-[10px] font-bold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-xs border border-emerald-200">
                        {t.affiliation}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="bg-slate-100 p-3 px-6 border-t border-slate-200 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">Official DGT Standardized Curriculum</span>
            <button
              onClick={() => {
                alert('Curriculum syllabus downloaded in PDF format.');
              }}
              className="bg-[#004f28] text-white px-4 py-1.5 rounded-xs text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" /> Download Full Syllabus PDF
            </button>
          </div>
        </div>
      )}

      {/* 4. PHOTO GALLERY MODAL */}
      {activeModal === 'gallery' && (
        <div className="bg-white w-full max-w-4xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#004f28] text-white p-4 flex items-center justify-between">
            <h3 className="font-bold text-sm">Govt ITI Udhampur - Campus &amp; Workshop Gallery</h3>
            <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Filter Pills */}
          <div className="bg-slate-100 p-2.5 px-6 border-b border-slate-200 flex items-center gap-2 text-xs overflow-x-auto">
            {['All', 'Workshops', 'Labs', 'Campus', 'Women Wing'].map((cat) => (
              <button
                key={cat}
                onClick={() => setGalleryFilter(cat)}
                className={`px-3 py-1 rounded-xs font-semibold transition-colors cursor-pointer ${
                  galleryFilter === cat
                    ? 'bg-[#004f28] text-white'
                    : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="p-6 overflow-y-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {gallery
                .filter((p) => galleryFilter === 'All' || p.category === galleryFilter)
                .map((photo) => (
                  <div key={photo.id} className="border border-slate-200 rounded-xs overflow-hidden shadow-xs group bg-slate-50">
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <img
                        src={photo.imageUrl}
                        alt={photo.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <span className="absolute top-2 left-2 bg-black/70 text-white text-[10px] font-bold px-2 py-0.5 rounded-xs">
                        {photo.category}
                      </span>
                    </div>
                    <div className="p-3">
                      <h4 className="text-xs font-bold text-slate-900">{photo.title}</h4>
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{photo.caption}</p>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. GRIEVANCE CELL MODAL */}
      {activeModal === 'grievance' && (
        <div className="bg-white w-full max-w-lg rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#06038d] text-white p-4 flex items-center justify-between">
            <h3 className="font-bold text-sm">Online Trainee Grievance &amp; Anti-Ragging Cell</h3>
            <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 overflow-y-auto">
            {grievanceSubmitted ? (
              <div className="text-center py-6 space-y-3">
                <CheckCircle className="w-12 h-12 text-emerald-600 mx-auto" />
                <h4 className="font-bold text-base text-slate-900">Grievance Registered Successfully</h4>
                <p className="text-xs text-slate-600">
                  Your reference tracking token is:
                </p>
                <div className="font-mono text-base font-bold text-[#06038d] bg-slate-100 p-2 rounded-xs">
                  {grievanceToken}
                </div>
                <p className="text-[11px] text-slate-500">
                  The Grievance Committee will address your matter within 7 working days.
                </p>
                <button
                  onClick={() => {
                    setGrievanceSubmitted(false);
                    closeModal();
                  }}
                  className="bg-[#06038d] text-white px-4 py-2 rounded-xs text-xs font-semibold mt-2 cursor-pointer"
                >
                  Close
                </button>
              </div>
            ) : (
              <form onSubmit={handleGrievanceSubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Trainee / Complainant Name *</label>
                  <input
                    type="text"
                    required
                    value={grievanceName}
                    onChange={(e) => setGrievanceName(e.target.value)}
                    placeholder="Your Name"
                    className="w-full p-2 border border-slate-300 rounded-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Enrolled Trade / Department</label>
                  <input
                    type="text"
                    value={grievanceTrade}
                    onChange={(e) => setGrievanceTrade(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Grievance Nature / Description *</label>
                  <textarea
                    required
                    rows={4}
                    value={grievanceDesc}
                    onChange={(e) => setGrievanceDesc(e.target.value)}
                    placeholder="Describe your issue or grievance with specific dates or workshop bay..."
                    className="w-full p-2 border border-slate-300 rounded-xs"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#06038d] hover:bg-[#2f33a8] text-white py-2 px-4 rounded-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" /> Submit Grievance
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* 6. DOWNLOAD PROSPECTUS MODAL */}
      {activeModal === 'download-prospectus' && (
        <div className="bg-white w-full max-w-md rounded-sm border border-slate-300 shadow-2xl p-6 text-center space-y-4">
          <div className="w-12 h-12 bg-emerald-100 text-[#004f28] rounded-full flex items-center justify-center mx-auto">
            <Download className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-base text-slate-900">
            Govt ITI Udhampur Admission Prospectus (2026-27)
          </h3>
          <p className="text-xs text-slate-600">
            Contains complete details on CTS admission guidelines, reservation quotas, fee structure, trade tool kits, and Dual System of Training (DST) guidelines.
          </p>
          <div className="bg-slate-50 p-3 rounded-xs border border-slate-200 text-xs font-mono text-slate-600">
            Document Size: <strong>4.8 MB (PDF)</strong> · Approved by DSD J&amp;K
          </div>
          <div className="flex gap-2 justify-center">
            <button
              onClick={() => {
                alert('Downloading Official Prospectus 2026-27 (4.8 MB)...');
                closeModal();
              }}
              className="bg-[#004f28] hover:bg-[#046a38] text-white px-5 py-2 rounded-xs font-semibold text-xs cursor-pointer"
            >
              Download PDF Now
            </button>
            <button
              onClick={closeModal}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-xs font-semibold text-xs cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* 7. PRINCIPAL FULL MESSAGE MODAL */}
      {activeModal === 'principal-speech' && (
        <div className="bg-white w-full max-w-2xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#004f28] text-white p-4 flex items-center justify-between">
            <h3 className="font-bold text-sm">Message from the Principal / Superintendent</h3>
            <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
            <div className="flex items-center gap-4 pb-4 border-b border-slate-200">
              <img
                src={principalDesk.photoUrl}
                alt={principalDesk.name}
                className="w-16 h-16 rounded-xs object-cover border border-slate-300 shadow-xs"
              />
              <div>
                <h4 className="font-bold text-slate-900 text-base">{principalDesk.name}</h4>
                <p className="text-xs text-[#004f28] font-semibold">{principalDesk.designation}</p>
                <p className="text-[11px] text-slate-500">{principalDesk.institute}</p>
              </div>
            </div>

            <p className="italic font-medium text-slate-800">
              {principalDesk.quote}
            </p>

            <p>
              {principalDesk.fullMessage}
            </p>

            <p>
              Vocational education is the most direct pathway to individual self-reliance and community prosperity. Through the generous patronage of the Directorate of Skill Development, Government of Jammu &amp; Kashmir and DGT Govt of India, our campus is consistently upgrading modern machinery, CNC lathes, electrical testing benches, and digital computer centers.
            </p>

            <div className="bg-[#eaedff] p-3 rounded-xs border-l-4 border-[#06038d]">
              <p className="font-bold text-[#06038d] font-serif">{principalDesk.slokaHindi}</p>
              <p className="text-[11px] text-slate-600 mt-1">{principalDesk.slokaEnglish}</p>
            </div>
          </div>
        </div>
      )}

      {/* 8. ALL CIRCULARS & DOWNLOADS MODAL */}
      {activeModal === 'all-circulars' && (
        <div className="bg-white w-full max-w-3xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#004f28] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-emerald-300" />
              <div>
                <h3 className="font-bold text-sm">All Institutional Orders, Circulars &amp; Downloads</h3>
                <p className="text-[11px] text-white/80">Govt Industrial Training Institute, Udhampur</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {isAdmin ? (
                <button
                  onClick={() => {
                    closeModal();
                    openAdminTab('orders');
                  }}
                  className="bg-white hover:bg-slate-100 text-[#004f28] px-3 py-1 rounded-xs text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>+ Upload New Order</span>
                </button>
              ) : (
                <button
                  onClick={() => openModal('admin-login')}
                  className="bg-white/10 hover:bg-white/20 text-white px-2.5 py-1 rounded-xs text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                >
                  <Lock className="w-3 h-3 text-emerald-300" />
                  <span>Admin Upload Login</span>
                </button>
              )}
              <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Search & Category Filter */}
          <div className="p-3 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={circularSearch}
                onChange={(e) => setCircularSearch(e.target.value)}
                placeholder="Search orders by title, reference, or keyword..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-xs focus:ring-1 focus:ring-[#004f28]"
              />
            </div>

            <div className="flex items-center gap-1 overflow-x-auto text-[11px]">
              {['ALL', 'URGENT', 'EXAM', 'TENDER', 'SCHEME', 'GENERAL'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCircularCatFilter(cat)}
                  className={`px-2 py-1 rounded-xs font-semibold cursor-pointer ${
                    circularCatFilter === cat
                      ? 'bg-[#004f28] text-white'
                      : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Circulars List */}
          <div className="p-4 overflow-y-auto space-y-3">
            {orders
              .filter((o) => {
                const matchesSearch =
                  o.title.toLowerCase().includes(circularSearch.toLowerCase()) ||
                  o.refNo.toLowerCase().includes(circularSearch.toLowerCase());
                const matchesCat = circularCatFilter === 'ALL' || o.category === circularCatFilter;
                return matchesSearch && matchesCat;
              })
              .map((ord) => (
                <div
                  key={ord.id}
                  className="p-3 bg-white border border-slate-200 hover:border-[#004f28] rounded-xs shadow-xs transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-xs bg-slate-100 text-slate-800 border">
                        {ord.category}
                      </span>
                      <span className="text-[11px] text-slate-500 font-mono">{ord.date}</span>
                      <span className="text-[11px] text-slate-400">· Ref: {ord.refNo}</span>
                    </div>
                    <h4
                      onClick={() => openModal('view-order', ord)}
                      className="text-xs sm:text-sm font-bold text-slate-900 hover:text-[#004f28] cursor-pointer leading-snug"
                    >
                      {ord.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                      Issued by: {ord.issuingAuthority} · {ord.downloadCount} views
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => openModal('view-order', ord)}
                      className="bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 px-2.5 py-1.5 rounded-xs text-xs font-semibold cursor-pointer"
                    >
                      View Text
                    </button>
                    <button
                      onClick={() => {
                        alert(`Downloading circular document: ${ord.title} (${ord.fileSize})`);
                      }}
                      className="bg-[#004f28] hover:bg-[#046a38] text-white px-3 py-1.5 rounded-xs text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{ord.fileSize}</span>
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* 9. TENDERS & E-PROCUREMENT MODAL */}
      {activeModal === 'tenders' && (
        <div className="bg-white w-full max-w-3xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#004f28] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-300" />
              <div>
                <h3 className="font-bold text-sm">Active Institute E-Tenders &amp; Procurements</h3>
                <p className="text-[11px] text-white/80">E-Procurement Cell, Directorate of Skill Development J&amp;K</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {isAdmin ? (
                <button
                  onClick={() => {
                    closeModal();
                    openAdminTab('tenders');
                  }}
                  className="bg-white hover:bg-slate-100 text-[#004f28] px-3 py-1 rounded-xs text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>+ Publish New Tender</span>
                </button>
              ) : (
                <button
                  onClick={() => openModal('admin-login')}
                  className="bg-white/10 hover:bg-white/20 text-white px-2.5 py-1 rounded-xs text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                >
                  <Lock className="w-3 h-3 text-emerald-300" />
                  <span>Admin Tender Login</span>
                </button>
              )}
              <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="p-4 bg-amber-50 border-b border-amber-200 text-xs text-amber-900 leading-relaxed">
            All prospective vendors and OEMs must submit technical and financial bids online through the J&amp;K e-Procurement Portal (<strong>jktenders.gov.in</strong>) before the closing deadlines indicated below.
          </div>

          <div className="p-4 overflow-y-auto space-y-3">
            {tenders.map((t) => (
              <div
                key={t.id}
                className="p-4 bg-white border border-slate-200 hover:border-[#004f28] rounded-xs shadow-xs space-y-2"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-mono text-xs font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded-xs border border-blue-200">
                    Tender ID: {t.tenderId}
                  </span>
                  <div className="text-[11px] text-slate-500 flex items-center gap-3">
                    <span>Published: <strong>{t.publishedDate}</strong></span>
                    <span className="text-red-700 font-semibold">Closing: <strong>{t.closingDate}</strong></span>
                  </div>
                </div>

                <h4 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">{t.title}</h4>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                  <div className="text-xs">
                    Estimated Cost: <strong className="text-[#004f28] font-bold">{t.estimatedValue}</strong>
                  </div>
                  <button
                    onClick={() => {
                      alert(`Downloading Bid Specifications Document: ${t.title} (${t.tenderDocSize})`);
                    }}
                    className="bg-[#004f28] hover:bg-[#046a38] text-white px-3 py-1.5 rounded-xs text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download RFP / Specs ({t.tenderDocSize})</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 10. RIGHT TO INFORMATION (RTI) MODAL */}
      {activeModal === 'rti' && (
        <div className="bg-white w-full max-w-2xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#06038d] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Scale className="w-5 h-5 text-indigo-300" />
              <div>
                <h3 className="font-bold text-sm">Right to Information Act 2005 - Citizen Portal</h3>
                <p className="text-[11px] text-white/80">Statutory Transparency &amp; Public Records Officer Directory</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {isAdmin && (
                <button
                  onClick={() => {
                    closeModal();
                    openAdminTab('disclosures');
                  }}
                  className="bg-white hover:bg-slate-100 text-[#06038d] px-3 py-1 rounded-xs text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Edit Officers</span>
                </button>
              )}
              <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-800">
            <div className="bg-slate-50 border border-slate-200 p-3 rounded-xs text-xs text-slate-700 leading-relaxed">
              In accordance with Section 4(1)(b) of the Right to Information Act 2005, citizens of India may seek official information regarding institutional functioning, CTS training allocations, procurement, and accounts.
            </div>

            <h4 className="font-bold text-slate-900 uppercase text-xs tracking-wider">
              Designated RTI Officers (Govt ITI Udhampur):
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {rtiOfficers.map((officer, idx) => (
                <div key={idx} className="p-4 bg-slate-50 border border-slate-200 rounded-xs space-y-1.5 text-xs">
                  <span className="text-[10px] font-bold text-[#06038d] uppercase tracking-wide block">
                    {officer.designation}
                  </span>
                  <h5 className="font-bold text-slate-900 text-sm">{officer.name}</h5>
                  <p className="text-slate-600 font-medium">{officer.officialRole}</p>
                  <div className="pt-2 border-t border-slate-200 space-y-1 text-[11px] text-slate-600">
                    <p className="flex items-center gap-1.5">
                      <Phone className="w-3 h-3 text-[#06038d]" /> {officer.phone}
                    </p>
                    <p className="flex items-center gap-1.5">
                      <Mail className="w-3 h-3 text-[#06038d]" /> {officer.email}
                    </p>
                    <p className="flex items-center gap-1.5">
                      <MapPin className="w-3 h-3 text-[#06038d]" /> {officer.officeAddress}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-[#eaedff] p-3 rounded-xs border-l-4 border-[#06038d] text-xs space-y-1 text-slate-700">
              <span className="font-bold text-[#06038d]">RTI Application Guidelines:</span>
              <p>Application Fee: ₹10/- through Indian Postal Order (IPO) or Demand Draft in favor of Principal, Govt ITI Udhampur.</p>
              <p>Response Time: Statutory 30 days from date of application receipt.</p>
            </div>
          </div>

          <div className="bg-slate-100 p-3 px-6 border-t border-slate-200 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">RTI Citizen Handbook</span>
            <button
              onClick={() => {
                alert('Downloading RTI 17-Manuals Citizen Charter Handbook (PDF 1.4 MB)...');
              }}
              className="bg-[#06038d] hover:bg-[#2f33a8] text-white px-4 py-1.5 rounded-xs text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" /> Download RTI Handbook PDF
            </button>
          </div>
        </div>
      )}

      {/* 11. CAMPUS FACILITIES & WORKSHOPS MODAL */}
      {activeModal === 'campus-facilities' && (
        <div className="bg-white w-full max-w-3xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#a73a00] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-amber-200" />
              <div>
                <h3 className="font-bold text-sm">Institute History &amp; Workshop Facilities</h3>
                <p className="text-[11px] text-white/80">Govt Industrial Training Institute, Udhampur (ESTD 1974)</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {isAdmin && (
                <button
                  onClick={() => {
                    closeModal();
                    openAdminTab('facilities');
                  }}
                  className="bg-white hover:bg-slate-100 text-[#a73a00] px-3 py-1 rounded-xs text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>+ Register Facility</span>
                </button>
              )}
              <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="p-6 overflow-y-auto space-y-4">
            <div className="space-y-2 text-xs sm:text-sm text-slate-700 leading-relaxed border-b border-slate-200 pb-4">
              <h4 className="font-bold text-slate-900 text-sm">50 Years of Vocational Heritage</h4>
              <p>
                Govt ITI Udhampur was established in 1974 to equip the youth of Jammu &amp; Kashmir with self-employable technical vocations. Centrally situated along Dhar Road near District Hospital and Subhash Stadium, the campus spans 14 kanals of green campus land housing specialized workshop blocks, computerized drafting bays, and solar simulation rigs.
              </p>
            </div>

            <h4 className="font-bold text-slate-900 uppercase text-xs tracking-wider">
              Workshops &amp; Practical Infrastructure ({facilities.length}):
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {facilities.map((fac) => (
                <div key={fac.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xs space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-xs">
                      {fac.category}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-500 font-mono">{fac.capacity}</span>
                  </div>
                  <h5 className="font-bold text-slate-900 text-sm leading-snug">{fac.name}</h5>
                  <p className="text-[#004f28] font-semibold text-[11px]">
                    Machinery: {fac.machinery}
                  </p>
                  <p className="text-slate-600 leading-relaxed text-[11px]">{fac.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 12. MANDATORY DISCLOSURES MODAL */}
      {activeModal === 'mandatory-disclosures' && (
        <div className="bg-white w-full max-w-2xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#004f28] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-300" />
              <div>
                <h3 className="font-bold text-sm">Mandatory Disclosures &amp; Compliance Records</h3>
                <p className="text-[11px] text-white/80">Approved under DGT &amp; Directorate of Skill Development J&amp;K</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {isAdmin && (
                <button
                  onClick={() => {
                    closeModal();
                    openAdminTab('disclosures');
                  }}
                  className="bg-white hover:bg-slate-100 text-[#004f28] px-3 py-1 rounded-xs text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>+ Upload Compliance Doc</span>
                </button>
              )}
              <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="p-4 overflow-y-auto divide-y divide-slate-100">
            {mandatoryDisclosures.map((doc) => (
              <div key={doc.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                <div>
                  <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded-xs uppercase">
                    {doc.category}
                  </span>
                  <h4 className="font-bold text-slate-900 text-xs sm:text-sm mt-1">{doc.title}</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 font-mono">
                    Order Ref: {doc.docNumber} · Approved: {doc.approvalDate}
                  </p>
                </div>

                <button
                  onClick={() => {
                    alert(`Downloading Verified Compliance Document: ${doc.title} (${doc.fileSize})`);
                  }}
                  className="bg-[#004f28] hover:bg-[#046a38] text-white px-3 py-1.5 rounded-xs text-xs font-semibold flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{doc.fileSize}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 13. ACADEMIC & EXAMINATION CALENDAR MODAL */}
      {activeModal === 'academic-calendar' && (
        <div className="bg-white w-full max-w-2xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#06038d] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-300" />
              <div>
                <h3 className="font-bold text-sm">Annual Academic &amp; Examination Calendar (2026-27)</h3>
                <p className="text-[11px] text-white/80">Craftsmen Training Scheme (CTS) Schedules</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {isAdmin && (
                <button
                  onClick={() => {
                    closeModal();
                    openAdminTab('events');
                  }}
                  className="bg-white hover:bg-slate-100 text-[#06038d] px-3 py-1 rounded-xs text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>+ Schedule Event</span>
                </button>
              )}
              <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="p-4 overflow-y-auto space-y-3">
            {events.map((ev) => (
              <div key={ev.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xs flex items-start gap-3">
                <div className="w-12 text-center bg-[#06038d] text-white rounded-xs overflow-hidden shrink-0">
                  <div className="text-sm font-bold py-1">{ev.day}</div>
                  <div className="text-[9px] font-bold py-0.5 bg-indigo-950 text-indigo-200">{ev.monthYear}</div>
                </div>
                <div className="flex-1 text-xs">
                  <span className="text-[9px] font-bold bg-indigo-100 text-[#06038d] px-1.5 py-0.5 rounded-xs uppercase">
                    {ev.category}
                  </span>
                  <h4 className="font-bold text-slate-900 mt-1">{ev.title}</h4>
                  <p className="text-slate-600 mt-0.5 text-[11px]">{ev.description}</p>
                  {ev.venue && <p className="text-slate-500 text-[10px] mt-1">📍 Venue: {ev.venue}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 14. ADMIN DATA ENTRY GUIDE & DIRECTORY MODAL */}
      {activeModal === 'admin-guide' && (
        <div className="bg-white w-full max-w-3xl rounded-sm border border-slate-300 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
          <div className="bg-[#004f28] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-amber-300" />
              <div>
                <h3 className="font-bold text-sm">Where &amp; How to Enter Data for Every Function / Button</h3>
                <p className="text-[11px] text-white/80">Govt ITI Udhampur CMS Directory</p>
              </div>
            </div>
            <button onClick={closeModal} className="text-white/80 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 overflow-y-auto space-y-3.5">
            <p className="text-xs text-slate-700">
              Each button or card on this portal is connected directly to the CMS. Click any button below to jump straight to that function's data entry form:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { name: 'Upload Circulars / Merit Lists', head: 'Downloads & Circulars', tab: 'orders' },
                { name: 'Publish E-Tenders & Bids', head: 'Institute Tenders', tab: 'tenders' },
                { name: 'Update Campus & Workshop Photos', head: 'Hero & Photo Gallery', tab: 'photos' },
                { name: 'Add / Edit CTS Trades & Seats', head: 'Vocational Matrix', tab: 'trades' },
                { name: 'Schedule Events & Exams', head: 'Upcoming Events & Calendar', tab: 'events' },
                { name: 'Register Workshops & Machinery', head: 'History & Facilities', tab: 'facilities' },
                { name: 'Edit RTI Officers & Disclosures', head: 'Right to Info & NOCs', tab: 'disclosures' },
                { name: 'Edit Urgent Marquee Alerts', head: 'Top Rolling Ticker', tab: 'alerts' },
                { name: "Update Principal's Speech & Quote", head: "Principal's Desk", tab: 'principal' },
                { name: 'Update Address, Phone & Codes', head: 'Header, Footer & Contact', tab: 'institution' }
              ].map((item, i) => (
                <div key={i} className="p-3 bg-slate-50 border border-slate-200 rounded-xs flex items-center justify-between gap-2 text-xs">
                  <div>
                    <h5 className="font-bold text-slate-900">{item.name}</h5>
                    <p className="text-[11px] text-slate-500">Affects: {item.head}</p>
                  </div>
                  <button
                    onClick={() => {
                      closeModal();
                      openAdminTab(item.tab);
                    }}
                    className="bg-[#004f28] hover:bg-[#046a38] text-white px-2.5 py-1.5 rounded-xs font-semibold text-[11px] cursor-pointer shrink-0"
                  >
                    Enter Data →
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
