import React, { useState } from 'react';
import { usePortal } from '../context/PortalContext';
import { Lock, ShieldCheck, X, CheckCircle, Sparkles } from 'lucide-react';

export const AdminLoginModal: React.FC = () => {
  const { activeModal, closeModal, loginAdmin } = usePortal();
  const [username, setUsername] = useState('admin@itiudhampur.gov.in');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  if (activeModal !== 'admin-login') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const res = loginAdmin(username, password);
    if (res.success) {
      setSuccess(res.message);
      setTimeout(() => {
        setSuccess('');
        closeModal();
      }, 700);
    } else {
      setError(res.message);
    }
  };

  const handleQuickDemoLogin = () => {
    setUsername('admin@itiudhampur.gov.in');
    setPassword('admin123');
    const res = loginAdmin('admin@itiudhampur.gov.in', 'admin123');
    if (res.success) {
      setSuccess('Logged in as Superintendent / Portal Administrator!');
      setTimeout(() => {
        setSuccess('');
        closeModal();
      }, 600);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-sm border border-slate-300 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-[#004f28] text-white p-4 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="bg-white/15 p-2 rounded-xs">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">ITI Administrative Login</h3>
              <p className="text-xs text-white/80">Govt ITI Udhampur Portal CMS</p>
            </div>
          </div>
          <button
            onClick={closeModal}
            className="text-white/80 hover:text-white p-1 rounded hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="mb-4 bg-amber-50 border border-amber-200 p-3 rounded-xs text-xs text-amber-900 leading-relaxed">
            <div className="font-semibold text-amber-950 flex items-center gap-1.5 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-700" /> Authorized Institutional Access
            </div>
            Superintendent &amp; IT Administrator portal to upload orders, update photos, manage trades, and edit all website domains.
          </div>

          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-800 text-xs p-2.5 rounded-xs">
              {error}
            </div>
          )}

          {success && (
            <div className="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-2.5 rounded-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{success}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Admin User ID / Official Email
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xs focus:outline-none focus:border-[#004f28] focus:ring-1 focus:ring-[#004f28]"
                placeholder="admin@itiudhampur.gov.in"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Security Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xs focus:outline-none focus:border-[#004f28] focus:ring-1 focus:ring-[#004f28]"
                placeholder="••••••••"
                required
              />
            </div>

            <div className="pt-2 space-y-2">
              <button
                type="submit"
                className="w-full bg-[#004f28] hover:bg-[#046a38] text-white py-2.5 px-4 rounded-xs font-semibold text-sm transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Lock className="w-4 h-4" /> Sign In to CMS Portal
              </button>

              <button
                type="button"
                onClick={handleQuickDemoLogin}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 py-2 px-4 rounded-xs font-medium text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                ⚡ 1-Click Fast Login (Pre-filled Demo Credentials)
              </button>
            </div>
          </form>

          <div className="mt-5 pt-4 border-t border-slate-200 text-center text-[11px] text-slate-500">
            Default credentials: <span className="font-mono text-slate-700">admin@itiudhampur.gov.in</span> / <span className="font-mono text-slate-700">admin123</span>
          </div>
        </div>
      </div>
    </div>
  );
};
