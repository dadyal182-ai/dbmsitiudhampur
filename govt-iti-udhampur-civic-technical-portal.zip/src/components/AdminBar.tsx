import React from 'react';
import { usePortal } from '../context/PortalContext';
import { ShieldCheck, PlusCircle, Image as ImageIcon, Sliders, LogOut, RefreshCcw, BookOpen, AlertCircle } from 'lucide-react';

export const AdminBar: React.FC = () => {
  const { isAdmin, adminUsername, logoutAdmin, openAdminTab, resetToDefaults } = usePortal();

  if (!isAdmin) return null;

  const handleReset = () => {
    if (window.confirm('Reset all edited content to the official Govt ITI Udhampur defaults?')) {
      resetToDefaults();
    }
  };

  return (
    <div className="bg-[#131b2e] text-white border-b-2 border-[#fd661d] px-4 py-2 sticky top-0 z-40 shadow-md">
      <div className="max-w-[1240px] mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-emerald-300">ADMIN MODE ACTIVE:</span>
          <span className="text-slate-300 hidden sm:inline">{adminUsername}</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => openAdminTab('orders')}
            className="bg-[#004f28] hover:bg-[#046a38] text-white px-2.5 py-1.5 rounded-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Upload new order, circular, or tender document"
          >
            <PlusCircle className="w-3.5 h-3.5 text-emerald-300" />
            <span>Upload New Order</span>
          </button>

          <button
            onClick={() => openAdminTab('photos')}
            className="bg-[#a73a00] hover:bg-[#fd661d] text-white px-2.5 py-1.5 rounded-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Update campus photos, hero banner, and workshop gallery"
          >
            <ImageIcon className="w-3.5 h-3.5 text-amber-200" />
            <span>Update Photos</span>
          </button>

          <button
            onClick={() => openAdminTab('trades')}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-2.5 py-1.5 rounded-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden md:inline">Trades &amp; Courses</span>
          </button>

          <button
            onClick={() => openAdminTab('hero')}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-2.5 py-1.5 rounded-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Sliders className="w-3.5 h-3.5 text-indigo-400" />
            <span>Full CMS Panel</span>
          </button>

          <button
            onClick={() => openAdminTab('sheets')}
            className="bg-emerald-800 hover:bg-emerald-700 text-white border border-emerald-600 px-2.5 py-1.5 rounded-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            title="Manage and synchronize data with Google Sheets"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse"></span>
            <span>Google Sheets</span>
          </button>

          <button
            onClick={() => openAdminTab('guide')}
            className="bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 px-2.5 py-1.5 rounded-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Overview of all portal heads and how to enter data"
          >
            <AlertCircle className="w-3.5 h-3.5 text-emerald-300" />
            <span>Data Entry Guide</span>
          </button>

          <button
            onClick={handleReset}
            className="bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white px-2 py-1.5 rounded-xs flex items-center gap-1 transition-colors cursor-pointer"
            title="Reset to default screenshot values"
          >
            <RefreshCcw className="w-3 h-3" />
            <span className="hidden lg:inline">Reset Defaults</span>
          </button>

          <button
            onClick={logoutAdmin}
            className="bg-red-950/80 hover:bg-red-900 text-red-200 border border-red-800 px-2.5 py-1.5 rounded-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Exit Admin</span>
          </button>
        </div>
      </div>
    </div>
  );
};
