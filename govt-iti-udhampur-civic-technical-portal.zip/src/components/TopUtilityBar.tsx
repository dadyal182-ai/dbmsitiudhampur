import React, { useState, useEffect } from 'react';
import { usePortal } from '../context/PortalContext';
import { Phone, Mail, UserCheck, Shield, ExternalLink, Globe } from 'lucide-react';

export const TopUtilityBar: React.FC = () => {
  const {
    institution,
    fontSize,
    setFontSize,
    language,
    setLanguage,
    isAdmin,
    openModal,
    setIsEditDrawerOpen
  } = usePortal();

  // Simulated live or date/time matching screenshot
  const [currentDateTime, setCurrentDateTime] = useState('Thursday, 29 May 2026 | IST 10:45 AM');

  useEffect(() => {
    // Keep updated or format nicely
    const updateTime = () => {
      const now = new Date();
      // Format as e.g. Thursday, 29 May 2026 | IST 10:45 AM
      const dateStr = now.toLocaleDateString('en-GB', {
        weekday: 'long',
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });
      const timeStr = now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
      // We can preserve the official date format:
      setCurrentDateTime(`${dateStr} | IST ${timeStr}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-[#f2f3ff] text-[#131b2e] border-b border-[#bec9be]/40 text-[11px] font-medium py-1 px-3 sm:px-6">
      <div className="max-w-[1240px] mx-auto flex flex-wrap items-center justify-between gap-y-1.5">
        
        {/* Left: Date & Time */}
        <div className="flex items-center space-x-3 text-slate-700">
          <span className="font-semibold text-slate-900 tracking-tight">
            {currentDateTime}
          </span>
        </div>

        {/* Right: Helpline, Email, Font size, Lang, National Links & Admin Trigger */}
        <div className="flex items-center flex-wrap gap-x-4 gap-y-1 text-slate-700">
          
          {/* Helpline & Email */}
          <div className="hidden md:flex items-center space-x-3 border-r border-slate-300 pr-3">
            <a
              href={`tel:${institution.helpline.replace(/\s+/g, '')}`}
              className="flex items-center gap-1 hover:text-[#004f28] transition-colors"
            >
              <Phone className="w-3 h-3 text-[#004f28]" />
              <span>Helpline: <strong className="font-semibold">{institution.helpline}</strong></span>
            </a>
            <span className="text-slate-300">|</span>
            <a
              href={`mailto:${institution.email}`}
              className="flex items-center gap-1 hover:text-[#004f28] transition-colors"
            >
              <Mail className="w-3 h-3 text-[#004f28]" />
              <span>{institution.email}</span>
            </a>
          </div>

          {/* Accessibility Font Size Controls */}
          <div className="flex items-center space-x-1 border-r border-slate-300 pr-3">
            <button
              onClick={() => setFontSize('sm')}
              className={`px-1.5 py-0.5 rounded-xs text-[10px] font-bold transition-colors cursor-pointer ${
                fontSize === 'sm' ? 'bg-[#004f28] text-white' : 'hover:bg-slate-200 text-slate-700'
              }`}
              title="Decrease Font Size"
            >
              A-
            </button>
            <button
              onClick={() => setFontSize('md')}
              className={`px-1.5 py-0.5 rounded-xs text-[11px] font-bold transition-colors cursor-pointer ${
                fontSize === 'md' ? 'bg-[#004f28] text-white' : 'hover:bg-slate-200 text-slate-700'
              }`}
              title="Reset Font Size"
            >
              A
            </button>
            <button
              onClick={() => setFontSize('lg')}
              className={`px-1.5 py-0.5 rounded-xs text-[12px] font-bold transition-colors cursor-pointer ${
                fontSize === 'lg' ? 'bg-[#004f28] text-white' : 'hover:bg-slate-200 text-slate-700'
              }`}
              title="Increase Font Size"
            >
              A+
            </button>
          </div>

          {/* Language Toggle */}
          <div className="flex items-center space-x-1 border-r border-slate-300 pr-3">
            <button
              onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
              className="flex items-center gap-1 hover:text-[#004f28] font-semibold text-slate-800 cursor-pointer"
              title="Switch language between English and Hindi"
            >
              <Globe className="w-3 h-3 text-[#004f28]" />
              <span>{language === 'en' ? 'हिंदी / English' : 'English / हिंदी'}</span>
            </button>
          </div>

          {/* External Gov Portals Pills (SKILL INDIA, DIGITAL INDIA, NCVT MIS) */}
          <div className="hidden lg:flex items-center space-x-2 border-r border-slate-300 pr-3 uppercase font-semibold text-[10px]">
            <a
              href="https://skillindiadigital.gov.in"
              target="_blank"
              rel="noreferrer"
              className="hover:text-[#004f28] hover:underline"
            >
              SKILL INDIA
            </a>
            <span className="text-slate-300">•</span>
            <a
              href="https://digitalindia.gov.in"
              target="_blank"
              rel="noreferrer"
              className="hover:text-[#004f28] hover:underline"
            >
              DIGITAL INDIA
            </a>
            <span className="text-slate-300">•</span>
            <a
              href="https://ncvtmis.gov.in"
              target="_blank"
              rel="noreferrer"
              className="hover:text-[#004f28] hover:underline"
            >
              NCVT MIS
            </a>
          </div>

          {/* Admin Login / CMS Status Button */}
          <div>
            {isAdmin ? (
              <button
                onClick={() => setIsEditDrawerOpen(true)}
                className="bg-[#004f28] text-white px-2 py-0.5 rounded-xs font-semibold flex items-center gap-1 hover:bg-[#046a38] transition-colors cursor-pointer text-[10px]"
                title="Superintendent Admin Logged In. Click to open CMS panel."
              >
                <Shield className="w-3 h-3 text-emerald-300" />
                <span>Admin CMS</span>
              </button>
            ) : (
              <button
                onClick={() => openModal('admin-login')}
                className="bg-slate-200 hover:bg-[#004f28] hover:text-white text-slate-800 px-2 py-0.5 rounded-xs font-medium flex items-center gap-1 transition-colors cursor-pointer text-[10px]"
                title="Sign in as Administrator / Superintendent"
              >
                <UserCheck className="w-3 h-3 text-slate-600 group-hover:text-white" />
                <span>Admin Login</span>
              </button>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
