import React from 'react';
import { usePortal } from '../context/PortalContext';
import {
  FileSpreadsheet,
  Scale,
  Download,
  Camera,
  Award,
  HeartHandshake
} from 'lucide-react';

export const CitizenHubSection: React.FC = () => {
  const { openModal } = usePortal();

  const hubItems = [
    {
      id: 'hub-1',
      title: 'Institute Tenders',
      subtitle: 'E-Procurement',
      icon: FileSpreadsheet,
      action: () => openModal('tenders')
    },
    {
      id: 'hub-2',
      title: 'Right to Info',
      subtitle: 'RTI Act 2005',
      icon: Scale,
      action: () => openModal('rti')
    },
    {
      id: 'hub-3',
      title: 'Downloads',
      subtitle: 'Forms & Circulars',
      icon: Download,
      action: () => openModal('all-circulars')
    },
    {
      id: 'hub-4',
      title: 'Photo Gallery',
      subtitle: 'Campus Workshops',
      icon: Camera,
      action: () => openModal('gallery')
    },
    {
      id: 'hub-5',
      title: 'NCVT MIS Portal',
      subtitle: 'Marks Sheets',
      icon: Award,
      action: () => window.open('https://ncvtmis.gov.in', '_blank')
    },
    {
      id: 'hub-6',
      title: 'Grievance Cell',
      subtitle: 'Anti-Ragging / Redress',
      icon: HeartHandshake,
      action: () => openModal('grievance')
    }
  ];

  return (
    <section className="py-8 bg-white border-b border-slate-200">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {hubItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={item.action}
                className="bg-[#faf8ff] hover:bg-[#eaedff] border border-slate-200 hover:border-[#004f28] p-4 rounded-xs text-center transition-all group flex flex-col items-center justify-center cursor-pointer shadow-xs"
              >
                <div className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-[#004f28] group-hover:scale-110 transition-transform mb-2 shadow-xs">
                  <Icon className="w-5 h-5 text-[#004f28]" />
                </div>
                <h3 className="text-xs font-bold text-slate-900 group-hover:text-[#004f28] leading-tight">
                  {item.title}
                </h3>
                <p className="text-[10px] text-slate-500 font-medium mt-0.5">
                  {item.subtitle}
                </p>
              </button>
            );
          })}
        </div>

      </div>
    </section>
  );
};
