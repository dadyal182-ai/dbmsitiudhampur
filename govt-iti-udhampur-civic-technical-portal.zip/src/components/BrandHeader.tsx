import React from 'react';
import { usePortal } from '../context/PortalContext';
import { Edit2 } from 'lucide-react';

export const BrandHeader: React.FC = () => {
  const { institution, isAdmin, openAdminTab } = usePortal();

  return (
    <header className="bg-white border-b border-slate-200 py-3.5 px-4 sm:px-6 relative">
      <div className="max-w-[1240px] mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Left: Emblems & Institution Identity */}
        <div className="flex items-center space-x-3.5 sm:space-x-4">
          
          {/* Government of India / J&K Emblem SVG */}
          <div className="shrink-0 flex items-center space-x-2">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center p-1 shadow-xs">
              <svg viewBox="0 0 100 100" className="w-full h-full text-slate-800" fill="currentColor">
                {/* Ashoka Chakra / Civic emblem representation */}
                <circle cx="50" cy="50" r="46" fill="none" stroke="#004f28" strokeWidth="3" />
                <circle cx="50" cy="50" r="41" fill="none" stroke="#a73a00" strokeWidth="1.5" strokeDasharray="3 2" />
                <circle cx="50" cy="50" r="16" fill="none" stroke="#06038d" strokeWidth="2.5" />
                {Array.from({ length: 24 }).map((_, i) => (
                  <line
                    key={i}
                    x1="50"
                    y1="50"
                    x2={50 + 15 * Math.cos((i * 15 * Math.PI) / 180)}
                    y2={50 + 15 * Math.sin((i * 15 * Math.PI) / 180)}
                    stroke="#06038d"
                    strokeWidth="1.2"
                  />
                ))}
                <path d="M50 15 L53 30 L47 30 Z" fill="#004f28" />
                <path d="M50 85 L53 70 L47 70 Z" fill="#004f28" />
                <path d="M15 50 L30 53 L30 47 Z" fill="#a73a00" />
                <path d="M85 50 L70 53 L70 47 Z" fill="#a73a00" />
              </svg>
            </div>

            {/* ITI Technical Crafts Emblem */}
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[#004f28]/5 border border-[#004f28]/30 flex items-center justify-center p-1 shadow-xs hidden sm:flex">
              <svg viewBox="0 0 100 100" className="w-full h-full" fill="none">
                {/* Technical Cog / Gear & Wrench Symbolism */}
                <circle cx="50" cy="50" r="32" stroke="#004f28" strokeWidth="6" />
                {Array.from({ length: 12 }).map((_, i) => (
                  <rect
                    key={i}
                    x="46"
                    y="10"
                    width="8"
                    height="12"
                    fill="#004f28"
                    rx="1"
                    transform={`rotate(${i * 30} 50 50)`}
                  />
                ))}
                <circle cx="50" cy="50" r="18" fill="#ffffff" stroke="#a73a00" strokeWidth="3" />
                <text x="50" y="55" fontSize="13" fontWeight="bold" fill="#004f28" textAnchor="middle">ITI</text>
              </svg>
            </div>
          </div>

          {/* Titles & Address */}
          <div>
            <p className="text-[11px] sm:text-[12px] font-bold text-slate-700 tracking-wider uppercase leading-none">
              {institution.state}
            </p>
            <p className="text-[12px] sm:text-[13px] font-semibold text-slate-800 leading-snug mt-0.5">
              {institution.department}
            </p>
            <h1 className="text-base sm:text-lg md:text-xl font-extrabold text-[#004f28] tracking-tight uppercase leading-tight mt-0.5">
              {institution.instituteName}
            </h1>
            <p className="text-[11.5px] sm:text-[12.5px] font-semibold text-slate-700 tracking-wide leading-normal mt-1 flex items-center gap-1.5">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#004f28] shrink-0"></span>
              <span>{institution.subLocation}</span>
            </p>
          </div>

          {/* Admin Edit Trigger */}
          {isAdmin && (
            <button
              onClick={() => openAdminTab('institution')}
              className="ml-2 p-1.5 bg-slate-100 hover:bg-[#004f28] hover:text-white text-slate-600 rounded-xs transition-colors cursor-pointer text-xs"
              title="Edit Institute Name, Address, and Code"
            >
              <Edit2 className="w-3.5 h-3.5" />
            </button>
          )}

        </div>

        {/* Right: National Affiliation Badges & Quick Links */}
        <div className="flex items-center space-x-3 self-end md:self-center">
          
          <div className="hidden sm:flex flex-col items-end text-right border-r border-slate-200 pr-3">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">AFFILIATION MATRIX</span>
            <span className="text-xs font-bold text-slate-800 font-mono">NCVT: {institution.ncvtMisCode}</span>
            <span className="text-[11px] text-emerald-800 font-semibold">{institution.affiliationText}</span>
          </div>

          {/* Skill India Brand Pill */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded-xs">
            <div className="w-6 h-6 rounded-full bg-[#a73a00] text-white flex items-center justify-center font-bold text-[10px]">
              कौशल
            </div>
            <div className="text-left leading-none">
              <span className="block text-[10px] font-extrabold text-[#a73a00]">Skill India</span>
              <span className="block text-[8px] text-slate-500 font-semibold uppercase">कौशल भारत · कुशल भारत</span>
            </div>
          </div>

          {/* Digital India Brand Pill */}
          <div className="hidden lg:flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded-xs">
            <div className="w-6 h-6 rounded-full bg-[#06038d] text-white flex items-center justify-center font-bold text-[10px]">
              DI
            </div>
            <div className="text-left leading-none">
              <span className="block text-[10px] font-extrabold text-[#06038d]">Digital India</span>
              <span className="block text-[8px] text-slate-500 font-semibold uppercase">Power to Empower</span>
            </div>
          </div>

        </div>

      </div>
    </header>
  );
};
