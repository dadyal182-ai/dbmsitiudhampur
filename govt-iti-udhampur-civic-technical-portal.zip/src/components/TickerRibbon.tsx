import React, { useState, useEffect } from 'react';
import { usePortal } from '../context/PortalContext';
import { Bell, ArrowRight, ChevronRight, Pause, Play, Edit2 } from 'lucide-react';

export const TickerRibbon: React.FC = () => {
  const { tickerAlerts, isAdmin, openAdminTab } = usePortal();
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused || tickerAlerts.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIdx((prev) => (prev + 1) % tickerAlerts.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [isPaused, tickerAlerts.length]);

  return (
    <div className="bg-[#a73a00] text-white text-xs border-b border-[#571a00] shadow-inner relative z-20">
      <div className="max-w-[1240px] mx-auto flex flex-col sm:flex-row items-stretch sm:items-center">
        
        {/* Urgent Badge on Left */}
        <div className="bg-[#571a00] text-[#ffdbce] px-3.5 py-1.5 flex items-center gap-1.5 font-bold uppercase tracking-wider text-[11px] shrink-0 border-r border-amber-900/60">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-300"></span>
          </span>
          <span>LATEST UPDATES</span>
        </div>

        {/* Ticker Content */}
        <div
          className="flex-1 px-3 py-1.5 overflow-hidden flex items-center justify-between"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          <div className="flex items-center gap-2 overflow-hidden text-[12px] font-medium text-white/95">
            <span className="bg-amber-400/20 text-amber-200 uppercase font-extrabold text-[9px] px-1.5 py-0.5 rounded-xs shrink-0">
              ALERTS
            </span>
            <span className="truncate transition-all duration-300">
              {tickerAlerts[currentIdx] || 'Online Admission Notification for Academic Session 2026-27 released.'}
            </span>
          </div>

          {/* Quick Ticker Controls & Link */}
          <div className="flex items-center space-x-2 pl-2 shrink-0">
            {isAdmin && (
              <button
                onClick={() => openAdminTab('alerts')}
                className="bg-black/20 hover:bg-black/40 text-amber-200 px-1.5 py-0.5 rounded-xs text-[10px] flex items-center gap-1 cursor-pointer"
                title="Edit alerts"
              >
                <Edit2 className="w-3 h-3" />
                <span className="hidden md:inline">Edit</span>
              </button>
            )}

            <a
              href="#circulars"
              className="font-bold text-[11px] text-amber-100 hover:text-white flex items-center gap-0.5 hover:underline whitespace-nowrap pl-1"
            >
              <span>All Circulars</span>
              <ChevronRight className="w-3 h-3" />
            </a>
          </div>

        </div>

      </div>
    </div>
  );
};
