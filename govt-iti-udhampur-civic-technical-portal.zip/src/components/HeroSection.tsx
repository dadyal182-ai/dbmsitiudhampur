import React from 'react';
import { usePortal } from '../context/PortalContext';
import {
  Wrench,
  Download,
  ExternalLink,
  Award,
  Users,
  Briefcase,
  History,
  Edit2,
  Camera,
  MapPin
} from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { hero, isAdmin, openAdminTab, openModal } = usePortal();

  return (
    <section id="home" className="bg-[#faf8ff] py-8 sm:py-10 border-b border-slate-200">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Column (Content & Metrics) - 7 cols */}
          <div className="lg:col-span-7 space-y-5">
            
            {/* Accreditation Badge */}
            <div className="inline-flex items-center gap-2 bg-[#eaedff] text-[#004f28] border border-[#bec9be]/60 px-3 py-1 rounded-xs text-[11px] font-bold tracking-wide">
              <span className="w-2 h-2 rounded-full bg-[#004f28]"></span>
              <span>{hero.taglineBadge}</span>
              {isAdmin && (
                <button
                  onClick={() => openAdminTab('hero')}
                  className="ml-1 text-slate-500 hover:text-[#004f28]"
                  title="Edit hero details"
                >
                  <Edit2 className="w-3 h-3" />
                </button>
              )}
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-[42px] font-black text-[#131b2e] leading-[1.15] tracking-tight">
              {hero.titlePrefix}
              <span className="relative inline-block text-[#004f28] decoration-[#004f28] underline underline-offset-4 decoration-4">
                {hero.titleHighlight}
              </span>
              {hero.titleSuffix}
            </h1>

            {/* Description */}
            <p className="text-sm sm:text-base text-slate-700 leading-relaxed max-w-2xl">
              {hero.description}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <a
                href="#trades"
                className="bg-[#004f28] hover:bg-[#046a38] text-white px-5 py-2.5 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-colors shadow-xs cursor-pointer"
              >
                <Wrench className="w-4 h-4 text-emerald-300" />
                <span>Explore 15+ Trades</span>
              </a>

              <button
                onClick={() => openModal('download-prospectus')}
                className="bg-white hover:bg-slate-50 text-[#004f28] border border-[#004f28] px-4 py-2.5 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Prospectus</span>
              </button>

              <button
                onClick={() => openModal('apply-online')}
                className="bg-[#a73a00] hover:bg-[#fd661d] text-white px-4 py-2.5 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
              >
                <span>Apply 2026-27</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Key Metrics Counter Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-200">
              
              <div className="bg-white p-3 rounded-xs border border-slate-200 shadow-xs">
                <div className="text-2xl font-black text-[#004f28] leading-none">
                  {hero.stat1Value}
                </div>
                <div className="text-xs font-bold text-slate-700 mt-1 leading-tight">
                  {hero.stat1Label}
                </div>
              </div>

              <div className="bg-white p-3 rounded-xs border border-slate-200 shadow-xs">
                <div className="text-2xl font-black text-[#06038d] leading-none">
                  {hero.stat2Value}
                </div>
                <div className="text-xs font-bold text-slate-700 mt-1 leading-tight">
                  {hero.stat2Label}
                </div>
              </div>

              <div className="bg-white p-3 rounded-xs border border-slate-200 shadow-xs">
                <div className="text-2xl font-black text-[#a73a00] leading-none">
                  {hero.stat3Value}
                </div>
                <div className="text-xs font-bold text-slate-700 mt-1 leading-tight">
                  {hero.stat3Label}
                </div>
                <div className="text-[10px] text-slate-500">{hero.stat3Sub}</div>
              </div>

              <div className="bg-white p-3 rounded-xs border border-slate-200 shadow-xs">
                <div className="text-2xl font-black text-slate-900 leading-none">
                  {hero.stat4Value}
                </div>
                <div className="text-xs font-bold text-slate-700 mt-1 leading-tight">
                  {hero.stat4Label}
                </div>
              </div>

            </div>

            <p className="text-[11px] text-slate-500 font-medium italic">
              Guiding the technical evolution and youth empowerment landscape in the Union Territory of Jammu &amp; Kashmir.
            </p>

          </div>

          {/* Right Column (Campus Photo Card) - 5 cols */}
          <div className="lg:col-span-5">
            <div className="relative rounded-sm overflow-hidden border border-slate-300 shadow-lg bg-slate-900 group">
              <img
                src={hero.heroPhotoUrl}
                alt="Govt ITI Udhampur Campus Life"
                className="w-full h-[320px] sm:h-[380px] object-cover transition-transform duration-500 group-hover:scale-105"
              />
              
              {/* Gradient Scrim for Text Readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent flex flex-col justify-end p-5 text-white">
                
                <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-emerald-400 mb-1">
                  <span className="bg-[#004f28] text-white px-2 py-0.5 rounded-xs font-bold">
                    CAMPUS LIFE
                  </span>
                  <span className="text-slate-200 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-emerald-400" />
                    Near District Hospital Udhampur
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-extrabold text-white leading-snug drop-shadow-xs">
                  {hero.heroPhotoCaption}
                </h3>

              </div>

              {/* Admin Photo Edit Button */}
              {isAdmin && (
                <button
                  onClick={() => openAdminTab('photos')}
                  className="absolute top-3 right-3 bg-black/70 hover:bg-[#a73a00] text-white p-2 rounded-xs text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-md"
                  title="Update campus photo"
                >
                  <Camera className="w-3.5 h-3.5 text-amber-300" />
                  <span>Update Photo</span>
                </button>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
