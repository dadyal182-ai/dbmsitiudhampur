import React, { useState } from 'react';
import { usePortal } from '../context/PortalContext';
import {
  FileText,
  Calendar,
  Download,
  ChevronLeft,
  ChevronRight,
  PlusCircle,
  ExternalLink,
  Clock,
  MapPin,
  CheckCircle,
  ArrowUpRight
} from 'lucide-react';
import { OrderCircular } from '../types';

export const NewsAndEventsSection: React.FC = () => {
  const { orders, events, isAdmin, openAdminTab, openModal } = usePortal();

  // Pagination / slice for Circulars
  const [newsPage, setNewsPage] = useState(0);
  const newsPerPage = 4;
  const totalNewsPages = Math.ceil(orders.length / newsPerPage);
  const currentOrders = orders.slice(newsPage * newsPerPage, (newsPage + 1) * newsPerPage);

  // Pagination / slice for Events
  const [eventPage, setEventPage] = useState(0);
  const eventsPerPage = 4;
  const totalEventPages = Math.ceil(events.length / eventsPerPage);
  const currentEvents = events.slice(eventPage * eventsPerPage, (eventPage + 1) * eventsPerPage);

  const getCategoryBadgeClass = (cat: string) => {
    switch (cat) {
      case 'URGENT':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'EXAM':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'TENDER':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'SCHEME':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
      case 'ADMISSION':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const getEventBadgeClass = (cat: string) => {
    switch (cat) {
      case 'PLACEMENT MELA':
        return 'bg-emerald-700 text-white';
      case 'CAMPUS FEST':
        return 'bg-[#a73a00] text-white';
      case 'WORKSHOP':
        return 'bg-[#06038d] text-white';
      case 'SAFETY DRILL':
        return 'bg-slate-700 text-white';
      case 'EXAM':
        return 'bg-purple-700 text-white';
      default:
        return 'bg-[#004f28] text-white';
    }
  };

  return (
    <section id="circulars" className="py-10 bg-white border-b border-slate-200">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          
          {/* Column A: Latest News & Circulars */}
          <div className="bg-[#faf8ff] border border-slate-200 rounded-xs p-5 shadow-xs flex flex-col justify-between">
            <div>
              {/* Header */}
              <div className="flex items-center justify-between pb-3.5 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-5 bg-[#004f28] rounded-xs"></div>
                  <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                    Latest News &amp; Circulars
                  </h2>
                </div>

                <div className="flex items-center space-x-1">
                  {isAdmin && (
                    <button
                      onClick={() => openAdminTab('orders')}
                      className="text-xs bg-[#004f28] hover:bg-[#046a38] text-white px-2 py-1 rounded-xs flex items-center gap-1 mr-2 font-medium cursor-pointer"
                      title="Upload new order"
                    >
                      <PlusCircle className="w-3 h-3" />
                      <span>Upload Order</span>
                    </button>
                  )}

                  <button
                    disabled={newsPage === 0}
                    onClick={() => setNewsPage(prev => Math.max(0, prev - 1))}
                    className="p-1 border border-slate-300 rounded-xs text-slate-600 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                    aria-label="Previous News"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    disabled={newsPage >= totalNewsPages - 1}
                    onClick={() => setNewsPage(prev => Math.min(totalNewsPages - 1, prev + 1))}
                    className="p-1 border border-slate-300 rounded-xs text-slate-600 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                    aria-label="Next News"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Circulars List */}
              <div className="divide-y divide-slate-200/80 my-2">
                {currentOrders.map((order) => (
                  <div key={order.id} className="py-3.5 group transition-colors">
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>{order.date}</span>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-xs border uppercase tracking-wider ${getCategoryBadgeClass(order.category)}`}>
                        {order.category}
                      </span>
                    </div>

                    <h3
                      onClick={() => openModal('view-order', order)}
                      className="text-xs sm:text-[13px] font-bold text-slate-900 group-hover:text-[#004f28] cursor-pointer transition-colors leading-snug"
                    >
                      {order.title}
                    </h3>

                    <div className="flex items-center justify-between gap-2 mt-2">
                      <span className="text-[11px] text-slate-500 truncate">
                        Ref: <strong className="font-medium text-slate-700">{order.refNo}</strong>
                      </span>

                      <button
                        onClick={() => openModal('view-order', order)}
                        className="bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 hover:text-[#004f28] hover:border-[#004f28] px-2.5 py-1 rounded-xs text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer shrink-0 shadow-xs"
                      >
                        <Download className="w-3 h-3 text-[#004f28]" />
                        <span>{order.fileSize || 'PDF (1.2 MB)'}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Button */}
            <div className="pt-3 border-t border-slate-200">
              <button
                onClick={() => openModal('all-circulars')}
                className="w-full bg-[#004f28] hover:bg-[#046a38] text-white py-2.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>VIEW ALL NEWS &amp; ARCHIVES</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Column B: Upcoming Events & Calendar */}
          <div className="bg-[#faf8ff] border border-slate-200 rounded-xs p-5 shadow-xs flex flex-col justify-between">
            <div>
              {/* Header */}
              <div className="flex items-center justify-between pb-3.5 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-5 bg-[#a73a00] rounded-xs"></div>
                  <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                    Upcoming Events &amp; Calendar
                  </h2>
                </div>

                <div className="flex items-center space-x-1">
                  {isAdmin && (
                    <button
                      onClick={() => openAdminTab('events')}
                      className="text-xs bg-[#a73a00] hover:bg-[#fd661d] text-white px-2 py-1 rounded-xs flex items-center gap-1 mr-2 font-medium cursor-pointer"
                      title="Schedule event"
                    >
                      <PlusCircle className="w-3 h-3" />
                      <span>Add Event</span>
                    </button>
                  )}

                  <button
                    disabled={eventPage === 0}
                    onClick={() => setEventPage(prev => Math.max(0, prev - 1))}
                    className="p-1 border border-slate-300 rounded-xs text-slate-600 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                    aria-label="Previous Events"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    disabled={eventPage >= totalEventPages - 1}
                    onClick={() => setEventPage(prev => Math.min(totalEventPages - 1, prev + 1))}
                    className="p-1 border border-slate-300 rounded-xs text-slate-600 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                    aria-label="Next Events"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Events List */}
              <div className="divide-y divide-slate-200/80 my-2">
                {currentEvents.map((event) => (
                  <div key={event.id} className="py-3.5 flex items-start gap-3.5 group">
                    {/* Date Block */}
                    <div className="shrink-0 w-12 text-center bg-[#004f28] text-white rounded-xs overflow-hidden shadow-xs">
                      <div className="text-sm font-black py-1 bg-[#004f28] border-b border-emerald-800">
                        {event.day}
                      </div>
                      <div className="text-[9px] font-bold py-0.5 bg-emerald-950 text-emerald-200">
                        {event.monthYear}
                      </div>
                    </div>

                    {/* Event Content */}
                    <div className="flex-1">
                      <div className="mb-1">
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-xs uppercase tracking-wider ${getEventBadgeClass(event.category)}`}>
                          {event.category}
                        </span>
                      </div>

                      <h3 className="text-xs sm:text-[13px] font-bold text-slate-900 group-hover:text-[#004f28] transition-colors leading-snug">
                        {event.title}
                      </h3>

                      <p className="text-[11px] text-slate-600 line-clamp-2 mt-1 leading-relaxed">
                        {event.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Button */}
            <div className="pt-3 border-t border-slate-200">
              <button
                onClick={() => openModal('academic-calendar')}
                className="w-full bg-[#e2e7ff] hover:bg-[#d0d1ff] text-[#06038d] py-2.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>VIEW COMPLETE ACADEMIC CALENDAR</span>
                <Calendar className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
