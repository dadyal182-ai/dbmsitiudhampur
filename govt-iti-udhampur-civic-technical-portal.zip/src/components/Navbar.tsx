import React, { useState } from 'react';
import { usePortal } from '../context/PortalContext';
import { Menu, X, ArrowRight, ExternalLink } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { openModal } = usePortal();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About Us', href: '#about' },
    { name: 'Trades & Courses', href: '#trades' },
    { name: 'Admissions', href: '#admissions' },
    { name: 'Trainee Corner', href: '#trainee' },
    { name: 'RTI & Tenders', href: '#tenders' },
    { name: 'Gallery & Media', href: '#gallery' },
    { name: 'Contact Us', href: '#contact' },
  ];

  return (
    <nav className="bg-[#004f28] text-white shadow-md relative z-30">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 flex items-center justify-between">
        
        {/* Desktop Nav Links */}
        <div className="hidden md:flex items-center space-x-1 lg:space-x-2 text-[13px] font-semibold py-0.5">
          {navLinks.map((link, idx) => (
            <a
              key={link.name}
              href={link.href}
              className={`px-3 py-3 transition-colors hover:bg-white/10 ${
                idx === 0 ? 'bg-black/20 font-bold border-b-2 border-[#fd661d]' : ''
              }`}
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Right Action: Apply Online 2026-27 */}
        <div className="hidden sm:block my-1.5">
          <button
            onClick={() => openModal('apply-online')}
            className="bg-[#a73a00] hover:bg-[#fd661d] text-white px-4 py-2 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer border border-amber-500/30"
          >
            <span>APPLY ONLINE 2026-27</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="flex md:hidden items-center justify-between w-full py-2">
          <span className="font-bold text-xs tracking-wider uppercase text-emerald-200">
            Navigation Menu
          </span>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 text-white hover:bg-white/10 rounded-xs"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#004f28] border-t border-emerald-800 px-4 py-3 space-y-1 text-sm font-semibold">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 px-3 hover:bg-white/10 rounded-xs"
            >
              {link.name}
            </a>
          ))}
          <div className="pt-2 border-t border-emerald-800/80">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openModal('apply-online');
              }}
              className="w-full bg-[#a73a00] hover:bg-[#fd661d] text-white py-2.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2"
            >
              <span>APPLY ONLINE 2026-27</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};
