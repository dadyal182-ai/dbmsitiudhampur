import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  InstitutionInfo,
  OrderCircular,
  EventItem,
  PrincipalDeskInfo,
  TradeItem,
  HeroInfo,
  GalleryPhoto,
  WhyChoosePoint,
  CitizenHubItem,
  NationalPortal,
  TenderNotice,
  RtiOfficer,
  FacilityItem,
  MandatoryDisclosureItem
} from '../types';
import {
  initialInstitutionInfo,
  initialHeroInfo,
  initialOrdersCirculars,
  initialEvents,
  initialPrincipalDesk,
  initialTrades,
  initialWhyChoose,
  initialCitizenHub,
  initialNationalPortals,
  initialGalleryPhotos,
  initialTickerAlerts,
  initialTenders,
  initialRtiOfficers,
  initialFacilities,
  initialMandatoryDisclosures
} from '../data/initialData';

interface PortalContextType {
  // Data
  institution: InstitutionInfo;
  hero: HeroInfo;
  orders: OrderCircular[];
  events: EventItem[];
  principalDesk: PrincipalDeskInfo;
  trades: TradeItem[];
  whyChoose: WhyChoosePoint[];
  citizenHub: CitizenHubItem[];
  nationalPortals: NationalPortal[];
  gallery: GalleryPhoto[];
  tickerAlerts: string[];
  tenders: TenderNotice[];
  rtiOfficers: RtiOfficer[];
  facilities: FacilityItem[];
  mandatoryDisclosures: MandatoryDisclosureItem[];

  // Admin state
  isAdmin: boolean;
  adminUsername: string;
  isEditDrawerOpen: boolean;
  activeAdminTab: string;
  openAdminTab: (tab: string) => void;
  setIsEditDrawerOpen: (open: boolean) => void;
  loginAdmin: (user: string, pass: string) => { success: boolean; message: string };
  logoutAdmin: () => void;

  // Accessibility & Lang
  fontSize: 'sm' | 'md' | 'lg';
  setFontSize: (size: 'sm' | 'md' | 'lg') => void;
  language: 'en' | 'hi';
  setLanguage: (lang: 'en' | 'hi') => void;

  // Modals
  activeModal: string | null;
  selectedOrderForModal: OrderCircular | null;
  selectedTradeForModal: TradeItem | null;
  openModal: (modalName: string, payload?: any) => void;
  closeModal: () => void;

  // Update actions
  updateInstitution: (info: Partial<InstitutionInfo>) => void;
  updateHero: (hero: Partial<HeroInfo>) => void;
  updatePrincipalDesk: (desk: Partial<PrincipalDeskInfo>) => void;
  
  // Orders
  addOrder: (order: Omit<OrderCircular, 'id' | 'downloadCount'>) => void;
  updateOrder: (id: string, order: Partial<OrderCircular>) => void;
  deleteOrder: (id: string) => void;

  // Events
  addEvent: (event: Omit<EventItem, 'id'>) => void;
  updateEvent: (id: string, event: Partial<EventItem>) => void;
  deleteEvent: (id: string) => void;

  // Trades
  addTrade: (trade: Omit<TradeItem, 'id'>) => void;
  updateTrade: (id: string, trade: Partial<TradeItem>) => void;
  deleteTrade: (id: string) => void;

  // Gallery Photos
  addPhoto: (photo: Omit<GalleryPhoto, 'id' | 'dateUploaded'>) => void;
  updatePhoto: (id: string, photo: Partial<GalleryPhoto>) => void;
  deletePhoto: (id: string) => void;

  // Tenders
  addTender: (tender: Omit<TenderNotice, 'id'>) => void;
  updateTender: (id: string, tender: Partial<TenderNotice>) => void;
  deleteTender: (id: string) => void;

  // RTI
  updateRtiOfficer: (idx: number, officer: Partial<RtiOfficer>) => void;

  // Facilities
  addFacility: (facility: Omit<FacilityItem, 'id'>) => void;
  deleteFacility: (id: string) => void;

  // Disclosures
  addMandatoryDisclosure: (item: Omit<MandatoryDisclosureItem, 'id'>) => void;
  deleteMandatoryDisclosure: (id: string) => void;

  // Ticker
  updateTickerAlerts: (alerts: string[]) => void;

  // Reset
  resetToDefaults: () => void;
}

const STORAGE_KEY = 'iti_udhampur_portal_storage_v1';
const AUTH_KEY = 'iti_udhampur_admin_auth_v1';

const PortalContext = createContext<PortalContextType | undefined>(undefined);

export const PortalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [institution, setInstitution] = useState<InstitutionInfo>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_institution`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.subLocation && parsed.subLocation.includes('Subhash Stadium')) {
          parsed.subLocation = 'Near District Hospital, Udhampur - 182101 (J&K)';
        }
        return parsed;
      }
      return initialInstitutionInfo;
    } catch {
      return initialInstitutionInfo;
    }
  });

  const [hero, setHero] = useState<HeroInfo>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_hero`);
      return saved ? JSON.parse(saved) : initialHeroInfo;
    } catch {
      return initialHeroInfo;
    }
  });

  const [orders, setOrders] = useState<OrderCircular[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_orders`);
      return saved ? JSON.parse(saved) : initialOrdersCirculars;
    } catch {
      return initialOrdersCirculars;
    }
  });

  const [events, setEvents] = useState<EventItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_events`);
      return saved ? JSON.parse(saved) : initialEvents;
    } catch {
      return initialEvents;
    }
  });

  const [principalDesk, setPrincipalDesk] = useState<PrincipalDeskInfo>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_principal`);
      return saved ? JSON.parse(saved) : initialPrincipalDesk;
    } catch {
      return initialPrincipalDesk;
    }
  });

  const [trades, setTrades] = useState<TradeItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_trades`);
      return saved ? JSON.parse(saved) : initialTrades;
    } catch {
      return initialTrades;
    }
  });

  const [gallery, setGallery] = useState<GalleryPhoto[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_gallery`);
      return saved ? JSON.parse(saved) : initialGalleryPhotos;
    } catch {
      return initialGalleryPhotos;
    }
  });

  const [tickerAlerts, setTickerAlerts] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_tickers`);
      return saved ? JSON.parse(saved) : initialTickerAlerts;
    } catch {
      return initialTickerAlerts;
    }
  });

  const [tenders, setTenders] = useState<TenderNotice[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_tenders`);
      return saved ? JSON.parse(saved) : initialTenders;
    } catch {
      return initialTenders;
    }
  });

  const [rtiOfficers, setRtiOfficers] = useState<RtiOfficer[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_rti`);
      return saved ? JSON.parse(saved) : initialRtiOfficers;
    } catch {
      return initialRtiOfficers;
    }
  });

  const [facilities, setFacilities] = useState<FacilityItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_facilities`);
      return saved ? JSON.parse(saved) : initialFacilities;
    } catch {
      return initialFacilities;
    }
  });

  const [mandatoryDisclosures, setMandatoryDisclosures] = useState<MandatoryDisclosureItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_disclosures`);
      return saved ? JSON.parse(saved) : initialMandatoryDisclosures;
    } catch {
      return initialMandatoryDisclosures;
    }
  });

  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    return localStorage.getItem(AUTH_KEY) === 'true';
  });

  const [adminUsername, setAdminUsername] = useState<string>(() => {
    return localStorage.getItem(`${AUTH_KEY}_user`) || 'Superintendent (Admin)';
  });

  const [isEditDrawerOpen, setIsEditDrawerOpen] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState('orders');
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg'>('md');
  const [language, setLanguage] = useState<'en' | 'hi'>('en');

  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [selectedOrderForModal, setSelectedOrderForModal] = useState<OrderCircular | null>(null);
  const [selectedTradeForModal, setSelectedTradeForModal] = useState<TradeItem | null>(null);

  // Persistence side effects
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_institution`, JSON.stringify(institution));
    } catch (e) { console.error(e); }
  }, [institution]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_hero`, JSON.stringify(hero));
    } catch (e) { console.error(e); }
  }, [hero]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_orders`, JSON.stringify(orders));
    } catch (e) { console.error(e); }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_events`, JSON.stringify(events));
    } catch (e) { console.error(e); }
  }, [events]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_principal`, JSON.stringify(principalDesk));
    } catch (e) { console.error(e); }
  }, [principalDesk]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_trades`, JSON.stringify(trades));
    } catch (e) { console.error(e); }
  }, [trades]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_gallery`, JSON.stringify(gallery));
    } catch (e) { console.error(e); }
  }, [gallery]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_tickers`, JSON.stringify(tickerAlerts));
    } catch (e) { console.error(e); }
  }, [tickerAlerts]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_tenders`, JSON.stringify(tenders));
    } catch (e) { console.error(e); }
  }, [tenders]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_rti`, JSON.stringify(rtiOfficers));
    } catch (e) { console.error(e); }
  }, [rtiOfficers]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_facilities`, JSON.stringify(facilities));
    } catch (e) { console.error(e); }
  }, [facilities]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_disclosures`, JSON.stringify(mandatoryDisclosures));
    } catch (e) { console.error(e); }
  }, [mandatoryDisclosures]);

  const loginAdmin = (user: string, pass: string) => {
    const validUsers = ['admin', 'admin@itiudhampur.gov.in', 'superintendent', 'itiudhampur'];
    const validPass = ['admin123', 'iti2026', 'admin'];

    const userMatch = validUsers.includes(user.trim().toLowerCase());
    const passMatch = validPass.includes(pass.trim()) || pass.trim() === 'admin123';

    if (userMatch && passMatch) {
      setIsAdmin(true);
      const displayName = 'Er. Ravinder Singh Bhatti (Superintendent / Admin)';
      setAdminUsername(displayName);
      localStorage.setItem(AUTH_KEY, 'true');
      localStorage.setItem(`${AUTH_KEY}_user`, displayName);
      return { success: true, message: 'Logged in as ITI Superintendent Administrator.' };
    } else {
      return { success: false, message: 'Invalid credentials. Use admin / admin123.' };
    }
  };

  const logoutAdmin = () => {
    setIsAdmin(false);
    setIsEditDrawerOpen(false);
    localStorage.removeItem(AUTH_KEY);
    localStorage.removeItem(`${AUTH_KEY}_user`);
  };

  const openAdminTab = (tab: string) => {
    setActiveAdminTab(tab);
    setIsEditDrawerOpen(true);
  };

  const openModal = (modalName: string, payload?: any) => {
    setActiveModal(modalName);
    if (modalName === 'view-order' && payload) {
      setSelectedOrderForModal(payload);
      setOrders(prev => prev.map(o => o.id === payload.id ? { ...o, downloadCount: o.downloadCount + 1 } : o));
    } else if (modalName === 'view-trade' && payload) {
      setSelectedTradeForModal(payload);
    }
  };

  const closeModal = () => {
    setActiveModal(null);
    setSelectedOrderForModal(null);
    setSelectedTradeForModal(null);
  };

  const updateInstitution = (info: Partial<InstitutionInfo>) => {
    setInstitution(prev => ({ ...prev, ...info, lastUpdated: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) }));
  };

  const updateHero = (newHero: Partial<HeroInfo>) => {
    setHero(prev => ({ ...prev, ...newHero }));
  };

  const updatePrincipalDesk = (desk: Partial<PrincipalDeskInfo>) => {
    setPrincipalDesk(prev => ({ ...prev, ...desk }));
  };

  const addOrder = (orderData: Omit<OrderCircular, 'id' | 'downloadCount'>) => {
    const newOrder: OrderCircular = {
      ...orderData,
      id: `ord-${Date.now()}`,
      downloadCount: 1
    };
    setOrders(prev => [newOrder, ...prev]);
  };

  const updateOrder = (id: string, updated: Partial<OrderCircular>) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, ...updated } : o));
  };

  const deleteOrder = (id: string) => {
    setOrders(prev => prev.filter(o => o.id !== id));
  };

  const addEvent = (eventData: Omit<EventItem, 'id'>) => {
    const newEvent: EventItem = {
      ...eventData,
      id: `ev-${Date.now()}`
    };
    setEvents(prev => [...prev, newEvent]);
  };

  const updateEvent = (id: string, updated: Partial<EventItem>) => {
    setEvents(prev => prev.map(e => e.id === id ? { ...e, ...updated } : e));
  };

  const deleteEvent = (id: string) => {
    setEvents(prev => prev.filter(e => e.id !== id));
  };

  const addTrade = (tradeData: Omit<TradeItem, 'id'>) => {
    const newTrade: TradeItem = {
      ...tradeData,
      id: `trade-${Date.now()}`
    };
    setTrades(prev => [...prev, newTrade]);
  };

  const updateTrade = (id: string, updated: Partial<TradeItem>) => {
    setTrades(prev => prev.map(t => t.id === id ? { ...t, ...updated } : t));
  };

  const deleteTrade = (id: string) => {
    setTrades(prev => prev.filter(t => t.id !== id));
  };

  const addPhoto = (photoData: Omit<GalleryPhoto, 'id' | 'dateUploaded'>) => {
    const newPhoto: GalleryPhoto = {
      ...photoData,
      id: `gal-${Date.now()}`,
      dateUploaded: new Date().toLocaleDateString('en-GB')
    };
    setGallery(prev => [newPhoto, ...prev]);
  };

  const updatePhoto = (id: string, updated: Partial<GalleryPhoto>) => {
    setGallery(prev => prev.map(p => p.id === id ? { ...p, ...updated } : p));
  };

  const deletePhoto = (id: string) => {
    setGallery(prev => prev.filter(p => p.id !== id));
  };

  const addTender = (tenderData: Omit<TenderNotice, 'id'>) => {
    const newTender: TenderNotice = {
      ...tenderData,
      id: `tnd-${Date.now()}`
    };
    setTenders(prev => [newTender, ...prev]);
  };

  const updateTender = (id: string, updated: Partial<TenderNotice>) => {
    setTenders(prev => prev.map(t => t.id === id ? { ...t, ...updated } : t));
  };

  const deleteTender = (id: string) => {
    setTenders(prev => prev.filter(t => t.id !== id));
  };

  const updateRtiOfficer = (idx: number, officer: Partial<RtiOfficer>) => {
    setRtiOfficers(prev => prev.map((o, i) => i === idx ? { ...o, ...officer } : o));
  };

  const addFacility = (facilityData: Omit<FacilityItem, 'id'>) => {
    const newFac: FacilityItem = {
      ...facilityData,
      id: `fac-${Date.now()}`
    };
    setFacilities(prev => [newFac, ...prev]);
  };

  const deleteFacility = (id: string) => {
    setFacilities(prev => prev.filter(f => f.id !== id));
  };

  const addMandatoryDisclosure = (itemData: Omit<MandatoryDisclosureItem, 'id'>) => {
    const newDoc: MandatoryDisclosureItem = {
      ...itemData,
      id: `md-${Date.now()}`
    };
    setMandatoryDisclosures(prev => [newDoc, ...prev]);
  };

  const deleteMandatoryDisclosure = (id: string) => {
    setMandatoryDisclosures(prev => prev.filter(d => d.id !== id));
  };

  const updateTickerAlerts = (alerts: string[]) => {
    setTickerAlerts(alerts);
  };

  const resetToDefaults = () => {
    setInstitution(initialInstitutionInfo);
    setHero(initialHeroInfo);
    setOrders(initialOrdersCirculars);
    setEvents(initialEvents);
    setPrincipalDesk(initialPrincipalDesk);
    setTrades(initialTrades);
    setGallery(initialGalleryPhotos);
    setTickerAlerts(initialTickerAlerts);
    setTenders(initialTenders);
    setRtiOfficers(initialRtiOfficers);
    setFacilities(initialFacilities);
    setMandatoryDisclosures(initialMandatoryDisclosures);

    localStorage.removeItem(`${STORAGE_KEY}_institution`);
    localStorage.removeItem(`${STORAGE_KEY}_hero`);
    localStorage.removeItem(`${STORAGE_KEY}_orders`);
    localStorage.removeItem(`${STORAGE_KEY}_events`);
    localStorage.removeItem(`${STORAGE_KEY}_principal`);
    localStorage.removeItem(`${STORAGE_KEY}_trades`);
    localStorage.removeItem(`${STORAGE_KEY}_gallery`);
    localStorage.removeItem(`${STORAGE_KEY}_tickers`);
    localStorage.removeItem(`${STORAGE_KEY}_tenders`);
    localStorage.removeItem(`${STORAGE_KEY}_rti`);
    localStorage.removeItem(`${STORAGE_KEY}_facilities`);
    localStorage.removeItem(`${STORAGE_KEY}_disclosures`);
  };

  return (
    <PortalContext.Provider
      value={{
        institution,
        hero,
        orders,
        events,
        principalDesk,
        trades,
        whyChoose: initialWhyChoose,
        citizenHub: initialCitizenHub,
        nationalPortals: initialNationalPortals,
        gallery,
        tickerAlerts,
        tenders,
        rtiOfficers,
        facilities,
        mandatoryDisclosures,
        isAdmin,
        adminUsername,
        isEditDrawerOpen,
        activeAdminTab,
        openAdminTab,
        setIsEditDrawerOpen,
        loginAdmin,
        logoutAdmin,
        fontSize,
        setFontSize,
        language,
        setLanguage,
        activeModal,
        selectedOrderForModal,
        selectedTradeForModal,
        openModal,
        closeModal,
        updateInstitution,
        updateHero,
        updatePrincipalDesk,
        addOrder,
        updateOrder,
        deleteOrder,
        addEvent,
        updateEvent,
        deleteEvent,
        addTrade,
        updateTrade,
        deleteTrade,
        addPhoto,
        updatePhoto,
        deletePhoto,
        addTender,
        updateTender,
        deleteTender,
        updateRtiOfficer,
        addFacility,
        deleteFacility,
        addMandatoryDisclosure,
        deleteMandatoryDisclosure,
        updateTickerAlerts,
        resetToDefaults
      }}
    >
      <div className={`transition-all duration-200 ${
        fontSize === 'sm' ? 'text-[13px]' : fontSize === 'lg' ? 'text-[17px]' : 'text-[15px]'
      }`}>
        {children}
      </div>
    </PortalContext.Provider>
  );
};

export const usePortal = () => {
  const context = useContext(PortalContext);
  if (!context) {
    throw new Error('usePortal must be used within a PortalProvider');
  }
  return context;
};
