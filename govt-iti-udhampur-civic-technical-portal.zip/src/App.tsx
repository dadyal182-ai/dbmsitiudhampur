/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PortalProvider } from './context/PortalContext';
import { AdminBar } from './components/AdminBar';
import { AdminLoginModal } from './components/AdminLoginModal';
import { AdminCMSDrawer } from './components/AdminCMSDrawer';
import { TopUtilityBar } from './components/TopUtilityBar';
import { BrandHeader } from './components/BrandHeader';
import { Navbar } from './components/Navbar';
import { TickerRibbon } from './components/TickerRibbon';
import { HeroSection } from './components/HeroSection';
import { NewsAndEventsSection } from './components/NewsAndEventsSection';
import { PrincipalAndAboutSection } from './components/PrincipalAndAboutSection';
import { VocationalMatrixSection } from './components/VocationalMatrixSection';
import { WhyChooseSection } from './components/WhyChooseSection';
import { CitizenHubSection } from './components/CitizenHubSection';
import { NationalPortalsSection } from './components/NationalPortalsSection';
import { CampusAccessibilitySection } from './components/CampusAccessibilitySection';
import { FooterSection } from './components/FooterSection';
import { Modals } from './components/Modals';

export default function App() {
  return (
    <PortalProvider>
      <div className="min-h-screen flex flex-col bg-[#faf8ff] text-[#131b2e] font-sans">
        {/* Sticky Admin Controls Bar (shown when Superintendent / Admin is logged in) */}
        <AdminBar />

        {/* Civic Top Utility Ribbon (Date, Helpline, Accessibility, Language, Admin Login) */}
        <TopUtilityBar />

        {/* Institutional Masthead / Brand Header */}
        <BrandHeader />

        {/* Primary Navigation Ribbon (Forest Green) */}
        <Navbar />

        {/* Urgent Bulletins & Rolling Marquee Ticker (Saffron) */}
        <TickerRibbon />

        {/* Main Content Sections */}
        <main className="flex-1">
          {/* Hero Section with CTS Craftsman Tagline, Metrics & Campus Photography */}
          <HeroSection />

          {/* Dual Column: Latest News & Circulars vs Upcoming Events */}
          <NewsAndEventsSection />

          {/* Dual Column: Principal's Desk vs About Govt ITI Udhampur */}
          <PrincipalAndAboutSection />

          {/* Vocational Matrix: 3 Sectors (IT, Heavy Engineering, Consumer Crafts) */}
          <VocationalMatrixSection />

          {/* Institutional Caliber: Why Choose Govt ITI Udhampur */}
          <WhyChooseSection />

          {/* Citizen Utility Rapid Hub: Tenders, RTI, Downloads, Gallery, NCVT, Grievance */}
          <CitizenHubSection />

          {/* National Apex Portals & Affiliations Strip */}
          <NationalPortalsSection />

          {/* Campus Accessibility & Dhar Road Geographic Map */}
          <CampusAccessibilitySection />
        </main>

        {/* Official Civic Footer with Records & Counter */}
        <FooterSection />

        {/* Interactive Modals (Orders, Admissions, Syllabus, Gallery, Grievance) */}
        <Modals />

        {/* Administrative Login Modal */}
        <AdminLoginModal />

        {/* Comprehensive Content Management System Drawer */}
        <AdminCMSDrawer />
      </div>
    </PortalProvider>
  );
}
