export interface InstitutionInfo {
  state: string;
  department: string;
  instituteName: string;
  subLocation: string;
  helpline: string;
  email: string;
  address: string;
  district: string;
  pincode: string;
  estdYear: string;
  ncvtCode: string;
  ncvtMisCode: string;
  affiliationText: string;
  workingHours: string;
  visitorCount: number;
  lastUpdated: string;
}

export type OrderCategory = 'URGENT' | 'EXAM' | 'TENDER' | 'SCHEME' | 'ADMISSION' | 'GENERAL';

export interface OrderCircular {
  id: string;
  title: string;
  refNo: string;
  date: string;
  category: OrderCategory;
  fileSize: string;
  fileUrl?: string;
  downloadCount: number;
  issuingAuthority: string;
  description?: string;
}

export type EventCategory = 'PLACEMENT MELA' | 'CAMPUS FEST' | 'WORKSHOP' | 'SAFETY DRILL' | 'EXAM' | 'SPORTS';

export interface EventItem {
  id: string;
  day: string;
  monthYear: string;
  category: EventCategory;
  title: string;
  description: string;
  time?: string;
  venue?: string;
}

export interface PrincipalDeskInfo {
  name: string;
  designation: string;
  institute: string;
  photoUrl: string;
  quote: string;
  slokaHindi: string;
  slokaEnglish: string;
  fullMessage: string;
}

export type SectorType = 'it' | 'engineering' | 'consumer';

export interface TradeItem {
  id: string;
  name: string;
  code?: string;
  sector: SectorType;
  duration: string;
  eligibility: string;
  affiliation: 'NCVT' | 'SCVT' | 'DST';
  seats?: number;
  description?: string;
}

export interface HeroInfo {
  taglineBadge: string;
  titlePrefix: string;
  titleHighlight: string;
  titleSuffix: string;
  description: string;
  stat1Value: string;
  stat1Label: string;
  stat2Value: string;
  stat2Label: string;
  stat3Value: string;
  stat3Label: string;
  stat3Sub: string;
  stat4Value: string;
  stat4Label: string;
  heroPhotoUrl: string;
  heroPhotoBadge: string;
  heroPhotoCaption: string;
}

export interface GalleryPhoto {
  id: string;
  title: string;
  category: 'Campus' | 'Workshops' | 'Labs' | 'Events' | 'Women Wing';
  imageUrl: string;
  caption: string;
  dateUploaded: string;
}

export interface WhyChoosePoint {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface CitizenHubItem {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  link: string;
}

export interface NationalPortal {
  id: string;
  name: string;
  subText: string;
  url: string;
}

export interface TenderNotice {
  id: string;
  tenderId: string;
  title: string;
  publishedDate: string;
  closingDate: string;
  estimatedValue: string;
  tenderDocSize: string;
  status: 'ACTIVE' | 'ARCHIVED' | 'CORRIGENDUM';
}

export interface RtiOfficer {
  designation: string;
  name: string;
  officialRole: string;
  phone: string;
  email: string;
  officeAddress: string;
}

export interface FacilityItem {
  id: string;
  name: string;
  category: 'Workshops' | 'Smart Labs' | 'Hostel & Amenities' | 'Renewable Energy';
  capacity: string;
  machinery: string;
  description: string;
}

export interface MandatoryDisclosureItem {
  id: string;
  title: string;
  category: 'Affiliation Order' | 'Building Safety' | 'Fire NOC' | 'Staff Structure';
  docNumber: string;
  approvalDate: string;
  fileSize: string;
}

export interface AdmissionApplication {
  id: string;
  refNo: string;
  applicantName: string;
  parentName: string;
  qualification: string;
  marksPercent: string;
  selectedTrade: string;
  mobileNo: string;
  submissionDate: string;
  status: 'PENDING' | 'VERIFIED' | 'SHORTLISTED' | 'ADMITTED';
}

export interface GrievanceRecord {
  id: string;
  token: string;
  name: string;
  trade: string;
  description: string;
  submissionDate: string;
  status: 'REGISTERED' | 'UNDER_REVIEW' | 'RESOLVED';
}
